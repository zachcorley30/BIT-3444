﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBWWUserInput
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblBWWTitle = New System.Windows.Forms.Label()
        Me.gbxBWWCarData = New System.Windows.Forms.GroupBox()
        Me.lblBWWCarSpecification = New System.Windows.Forms.Label()
        Me.tlpBWWCarInfo = New System.Windows.Forms.TableLayoutPanel()
        Me.lblBWWCarMake = New System.Windows.Forms.Label()
        Me.lblBWWCarModel = New System.Windows.Forms.Label()
        Me.lblBWWCarYear = New System.Windows.Forms.Label()
        Me.lblBWWTransmission = New System.Windows.Forms.Label()
        Me.txtBWWCarYear = New System.Windows.Forms.TextBox()
        Me.cbxBWWTransmission = New System.Windows.Forms.ComboBox()
        Me.cbxBWWCarMake = New System.Windows.Forms.ComboBox()
        Me.cbxBWWCarModel = New System.Windows.Forms.ComboBox()
        Me.btnBWWSolve = New System.Windows.Forms.Button()
        Me.rtbBWWSolution = New System.Windows.Forms.RichTextBox()
        Me.gbxBWWCarData.SuspendLayout()
        Me.tlpBWWCarInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblBWWTitle
        '
        Me.lblBWWTitle.AutoSize = True
        Me.lblBWWTitle.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWTitle.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWTitle.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblBWWTitle.Location = New System.Drawing.Point(134, 9)
        Me.lblBWWTitle.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblBWWTitle.Name = "lblBWWTitle"
        Me.lblBWWTitle.Size = New System.Drawing.Size(412, 25)
        Me.lblBWWTitle.TabIndex = 0
        Me.lblBWWTitle.Text = "What type of vehicle do you want to purchase?"
        '
        'gbxBWWCarData
        '
        Me.gbxBWWCarData.BackColor = System.Drawing.Color.Snow
        Me.gbxBWWCarData.Controls.Add(Me.lblBWWCarSpecification)
        Me.gbxBWWCarData.Controls.Add(Me.tlpBWWCarInfo)
        Me.gbxBWWCarData.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxBWWCarData.Location = New System.Drawing.Point(26, 48)
        Me.gbxBWWCarData.Margin = New System.Windows.Forms.Padding(1)
        Me.gbxBWWCarData.Name = "gbxBWWCarData"
        Me.gbxBWWCarData.Padding = New System.Windows.Forms.Padding(1)
        Me.gbxBWWCarData.Size = New System.Drawing.Size(366, 266)
        Me.gbxBWWCarData.TabIndex = 1
        Me.gbxBWWCarData.TabStop = False
        Me.gbxBWWCarData.Text = "Car Data"
        '
        'lblBWWCarSpecification
        '
        Me.lblBWWCarSpecification.AutoSize = True
        Me.lblBWWCarSpecification.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWCarSpecification.Font = New System.Drawing.Font("Arial Narrow", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWCarSpecification.Location = New System.Drawing.Point(11, 33)
        Me.lblBWWCarSpecification.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblBWWCarSpecification.Name = "lblBWWCarSpecification"
        Me.lblBWWCarSpecification.Size = New System.Drawing.Size(255, 20)
        Me.lblBWWCarSpecification.TabIndex = 1
        Me.lblBWWCarSpecification.Text = "What car specifications do you require?"
        '
        'tlpBWWCarInfo
        '
        Me.tlpBWWCarInfo.ColumnCount = 2
        Me.tlpBWWCarInfo.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpBWWCarInfo.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpBWWCarInfo.Controls.Add(Me.lblBWWCarMake, 0, 0)
        Me.tlpBWWCarInfo.Controls.Add(Me.lblBWWCarModel, 0, 1)
        Me.tlpBWWCarInfo.Controls.Add(Me.lblBWWCarYear, 0, 2)
        Me.tlpBWWCarInfo.Controls.Add(Me.lblBWWTransmission, 0, 3)
        Me.tlpBWWCarInfo.Controls.Add(Me.txtBWWCarYear, 1, 2)
        Me.tlpBWWCarInfo.Controls.Add(Me.cbxBWWTransmission, 1, 3)
        Me.tlpBWWCarInfo.Controls.Add(Me.cbxBWWCarMake, 1, 0)
        Me.tlpBWWCarInfo.Controls.Add(Me.cbxBWWCarModel, 1, 1)
        Me.tlpBWWCarInfo.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlpBWWCarInfo.Location = New System.Drawing.Point(15, 73)
        Me.tlpBWWCarInfo.Margin = New System.Windows.Forms.Padding(1)
        Me.tlpBWWCarInfo.Name = "tlpBWWCarInfo"
        Me.tlpBWWCarInfo.RowCount = 4
        Me.tlpBWWCarInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpBWWCarInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpBWWCarInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpBWWCarInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpBWWCarInfo.Size = New System.Drawing.Size(261, 154)
        Me.tlpBWWCarInfo.TabIndex = 0
        '
        'lblBWWCarMake
        '
        Me.lblBWWCarMake.AutoSize = True
        Me.lblBWWCarMake.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWCarMake.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWCarMake.Location = New System.Drawing.Point(1, 0)
        Me.lblBWWCarMake.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblBWWCarMake.Name = "lblBWWCarMake"
        Me.lblBWWCarMake.Size = New System.Drawing.Size(66, 20)
        Me.lblBWWCarMake.TabIndex = 0
        Me.lblBWWCarMake.Text = "Car Make"
        '
        'lblBWWCarModel
        '
        Me.lblBWWCarModel.AutoSize = True
        Me.lblBWWCarModel.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWCarModel.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWCarModel.Location = New System.Drawing.Point(1, 38)
        Me.lblBWWCarModel.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblBWWCarModel.Name = "lblBWWCarModel"
        Me.lblBWWCarModel.Size = New System.Drawing.Size(71, 20)
        Me.lblBWWCarModel.TabIndex = 1
        Me.lblBWWCarModel.Text = "Car Model"
        '
        'lblBWWCarYear
        '
        Me.lblBWWCarYear.AutoSize = True
        Me.lblBWWCarYear.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWCarYear.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWCarYear.Location = New System.Drawing.Point(1, 76)
        Me.lblBWWCarYear.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblBWWCarYear.Name = "lblBWWCarYear"
        Me.lblBWWCarYear.Size = New System.Drawing.Size(61, 20)
        Me.lblBWWCarYear.TabIndex = 2
        Me.lblBWWCarYear.Text = "Car Year"
        '
        'lblBWWTransmission
        '
        Me.lblBWWTransmission.AutoSize = True
        Me.lblBWWTransmission.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWTransmission.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWTransmission.Location = New System.Drawing.Point(1, 114)
        Me.lblBWWTransmission.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblBWWTransmission.Name = "lblBWWTransmission"
        Me.lblBWWTransmission.Size = New System.Drawing.Size(87, 20)
        Me.lblBWWTransmission.TabIndex = 3
        Me.lblBWWTransmission.Text = "Transmission"
        '
        'txtBWWCarYear
        '
        Me.txtBWWCarYear.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBWWCarYear.Location = New System.Drawing.Point(131, 77)
        Me.txtBWWCarYear.Margin = New System.Windows.Forms.Padding(1)
        Me.txtBWWCarYear.Name = "txtBWWCarYear"
        Me.txtBWWCarYear.Size = New System.Drawing.Size(129, 20)
        Me.txtBWWCarYear.TabIndex = 4
        '
        'cbxBWWTransmission
        '
        Me.cbxBWWTransmission.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxBWWTransmission.FormattingEnabled = True
        Me.cbxBWWTransmission.Location = New System.Drawing.Point(131, 115)
        Me.cbxBWWTransmission.Margin = New System.Windows.Forms.Padding(1)
        Me.cbxBWWTransmission.Name = "cbxBWWTransmission"
        Me.cbxBWWTransmission.Size = New System.Drawing.Size(129, 23)
        Me.cbxBWWTransmission.TabIndex = 5
        '
        'cbxBWWCarMake
        '
        Me.cbxBWWCarMake.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxBWWCarMake.FormattingEnabled = True
        Me.cbxBWWCarMake.Location = New System.Drawing.Point(131, 1)
        Me.cbxBWWCarMake.Margin = New System.Windows.Forms.Padding(1)
        Me.cbxBWWCarMake.Name = "cbxBWWCarMake"
        Me.cbxBWWCarMake.Size = New System.Drawing.Size(129, 23)
        Me.cbxBWWCarMake.TabIndex = 6
        '
        'cbxBWWCarModel
        '
        Me.cbxBWWCarModel.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxBWWCarModel.FormattingEnabled = True
        Me.cbxBWWCarModel.Location = New System.Drawing.Point(131, 39)
        Me.cbxBWWCarModel.Margin = New System.Windows.Forms.Padding(1)
        Me.cbxBWWCarModel.Name = "cbxBWWCarModel"
        Me.cbxBWWCarModel.Size = New System.Drawing.Size(129, 23)
        Me.cbxBWWCarModel.TabIndex = 7
        '
        'btnBWWSolve
        '
        Me.btnBWWSolve.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBWWSolve.Location = New System.Drawing.Point(497, 103)
        Me.btnBWWSolve.Margin = New System.Windows.Forms.Padding(1)
        Me.btnBWWSolve.Name = "btnBWWSolve"
        Me.btnBWWSolve.Size = New System.Drawing.Size(98, 40)
        Me.btnBWWSolve.TabIndex = 2
        Me.btnBWWSolve.Text = "Solve"
        Me.btnBWWSolve.UseVisualStyleBackColor = True
        '
        'rtbBWWSolution
        '
        Me.rtbBWWSolution.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbBWWSolution.Location = New System.Drawing.Point(497, 162)
        Me.rtbBWWSolution.Margin = New System.Windows.Forms.Padding(1)
        Me.rtbBWWSolution.Name = "rtbBWWSolution"
        Me.rtbBWWSolution.Size = New System.Drawing.Size(100, 101)
        Me.rtbBWWSolution.TabIndex = 3
        Me.rtbBWWSolution.Text = ""
        '
        'frmBWWUserInput
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Brown
        Me.ClientSize = New System.Drawing.Size(691, 375)
        Me.Controls.Add(Me.rtbBWWSolution)
        Me.Controls.Add(Me.btnBWWSolve)
        Me.Controls.Add(Me.gbxBWWCarData)
        Me.Controls.Add(Me.lblBWWTitle)
        Me.Margin = New System.Windows.Forms.Padding(1)
        Me.Name = "frmBWWUserInput"
        Me.Text = "User Input"
        Me.gbxBWWCarData.ResumeLayout(False)
        Me.gbxBWWCarData.PerformLayout()
        Me.tlpBWWCarInfo.ResumeLayout(False)
        Me.tlpBWWCarInfo.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBWWTitle As Label
    Friend WithEvents gbxBWWCarData As GroupBox
    Friend WithEvents lblBWWCarSpecification As Label
    Friend WithEvents tlpBWWCarInfo As TableLayoutPanel
    Friend WithEvents lblBWWCarMake As Label
    Friend WithEvents lblBWWCarModel As Label
    Friend WithEvents lblBWWCarYear As Label
    Friend WithEvents lblBWWTransmission As Label
    Friend WithEvents txtBWWCarYear As TextBox
    Friend WithEvents cbxBWWTransmission As ComboBox
    Friend WithEvents cbxBWWCarMake As ComboBox
    Friend WithEvents cbxBWWCarModel As ComboBox
    Friend WithEvents btnBWWSolve As Button
    Friend WithEvents rtbBWWSolution As RichTextBox
End Class
