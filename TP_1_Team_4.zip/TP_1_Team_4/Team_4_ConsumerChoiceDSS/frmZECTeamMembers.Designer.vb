﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmZECTeamMembers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmZECTeamMembers))
        Me.lblZECTeam = New System.Windows.Forms.Label()
        Me.lblZECZach = New System.Windows.Forms.Label()
        Me.lblZECzcor = New System.Windows.Forms.Label()
        Me.lblZECJohn = New System.Windows.Forms.Label()
        Me.lblZECjmhoff98 = New System.Windows.Forms.Label()
        Me.lblZECRebec = New System.Windows.Forms.Label()
        Me.lblZECRebecca = New System.Windows.Forms.Label()
        Me.lblZECMark = New System.Windows.Forms.Label()
        Me.lblZECmcurry = New System.Windows.Forms.Label()
        Me.lblZECBrendan = New System.Windows.Forms.Label()
        Me.lblZECbwight4 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblZECTeam
        '
        Me.lblZECTeam.AutoSize = True
        Me.lblZECTeam.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECTeam.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECTeam.Location = New System.Drawing.Point(370, 9)
        Me.lblZECTeam.Name = "lblZECTeam"
        Me.lblZECTeam.Size = New System.Drawing.Size(73, 25)
        Me.lblZECTeam.TabIndex = 1
        Me.lblZECTeam.Text = "Team 4"
        '
        'lblZECZach
        '
        Me.lblZECZach.AutoSize = True
        Me.lblZECZach.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECZach.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECZach.Location = New System.Drawing.Point(76, 193)
        Me.lblZECZach.Name = "lblZECZach"
        Me.lblZECZach.Size = New System.Drawing.Size(82, 20)
        Me.lblZECZach.TabIndex = 2
        Me.lblZECZach.Text = "Zach Corley"
        '
        'lblZECzcor
        '
        Me.lblZECzcor.AutoSize = True
        Me.lblZECzcor.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECzcor.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECzcor.Location = New System.Drawing.Point(72, 221)
        Me.lblZECzcor.Name = "lblZECzcor"
        Me.lblZECzcor.Size = New System.Drawing.Size(86, 20)
        Me.lblZECzcor.TabIndex = 3
        Me.lblZECzcor.Text = "zcor@vt.edu"
        '
        'lblZECJohn
        '
        Me.lblZECJohn.AutoSize = True
        Me.lblZECJohn.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECJohn.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECJohn.Location = New System.Drawing.Point(215, 349)
        Me.lblZECJohn.Name = "lblZECJohn"
        Me.lblZECJohn.Size = New System.Drawing.Size(96, 20)
        Me.lblZECJohn.TabIndex = 4
        Me.lblZECJohn.Text = "John Hoffman"
        '
        'lblZECjmhoff98
        '
        Me.lblZECjmhoff98.AutoSize = True
        Me.lblZECjmhoff98.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECjmhoff98.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECjmhoff98.Location = New System.Drawing.Point(207, 377)
        Me.lblZECjmhoff98.Name = "lblZECjmhoff98"
        Me.lblZECjmhoff98.Size = New System.Drawing.Size(114, 20)
        Me.lblZECjmhoff98.TabIndex = 5
        Me.lblZECjmhoff98.Text = "jmhoff98@vt.edu"
        '
        'lblZECRebec
        '
        Me.lblZECRebec.AutoSize = True
        Me.lblZECRebec.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECRebec.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECRebec.Location = New System.Drawing.Point(357, 221)
        Me.lblZECRebec.Name = "lblZECRebec"
        Me.lblZECRebec.Size = New System.Drawing.Size(108, 20)
        Me.lblZECRebec.TabIndex = 6
        Me.lblZECRebec.Text = "rebec98@vt.edu"
        '
        'lblZECRebecca
        '
        Me.lblZECRebecca.AutoSize = True
        Me.lblZECRebecca.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECRebecca.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECRebecca.Location = New System.Drawing.Point(357, 193)
        Me.lblZECRebecca.Name = "lblZECRebecca"
        Me.lblZECRebecca.Size = New System.Drawing.Size(109, 20)
        Me.lblZECRebecca.TabIndex = 7
        Me.lblZECRebecca.Text = "Rebecca Dryden"
        '
        'lblZECMark
        '
        Me.lblZECMark.AutoSize = True
        Me.lblZECMark.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECMark.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECMark.Location = New System.Drawing.Point(663, 193)
        Me.lblZECMark.Name = "lblZECMark"
        Me.lblZECMark.Size = New System.Drawing.Size(77, 20)
        Me.lblZECMark.TabIndex = 8
        Me.lblZECMark.Text = "Mark Curry"
        '
        'lblZECmcurry
        '
        Me.lblZECmcurry.AutoSize = True
        Me.lblZECmcurry.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECmcurry.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECmcurry.Location = New System.Drawing.Point(644, 221)
        Me.lblZECmcurry.Name = "lblZECmcurry"
        Me.lblZECmcurry.Size = New System.Drawing.Size(118, 20)
        Me.lblZECmcurry.TabIndex = 9
        Me.lblZECmcurry.Text = "mcurry16@vt.edu"
        '
        'lblZECBrendan
        '
        Me.lblZECBrendan.AutoSize = True
        Me.lblZECBrendan.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECBrendan.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECBrendan.Location = New System.Drawing.Point(524, 349)
        Me.lblZECBrendan.Name = "lblZECBrendan"
        Me.lblZECBrendan.Size = New System.Drawing.Size(100, 20)
        Me.lblZECBrendan.TabIndex = 10
        Me.lblZECBrendan.Text = "Brendan Wight"
        '
        'lblZECbwight4
        '
        Me.lblZECbwight4.AutoSize = True
        Me.lblZECbwight4.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECbwight4.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECbwight4.Location = New System.Drawing.Point(524, 376)
        Me.lblZECbwight4.Name = "lblZECbwight4"
        Me.lblZECbwight4.Size = New System.Drawing.Size(108, 20)
        Me.lblZECbwight4.TabIndex = 11
        Me.lblZECbwight4.Text = "bwight4@vt.edu"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(211, 176)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(104, 159)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(59, 29)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(119, 161)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 13
        Me.PictureBox2.TabStop = False
        '
        'frmZECTeamMembers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Brown
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblZECbwight4)
        Me.Controls.Add(Me.lblZECBrendan)
        Me.Controls.Add(Me.lblZECmcurry)
        Me.Controls.Add(Me.lblZECMark)
        Me.Controls.Add(Me.lblZECRebecca)
        Me.Controls.Add(Me.lblZECRebec)
        Me.Controls.Add(Me.lblZECjmhoff98)
        Me.Controls.Add(Me.lblZECJohn)
        Me.Controls.Add(Me.lblZECzcor)
        Me.Controls.Add(Me.lblZECZach)
        Me.Controls.Add(Me.lblZECTeam)
        Me.Name = "frmZECTeamMembers"
        Me.Text = "frmZECTeamMembers"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblZECTeam As Label
    Friend WithEvents lblZECZach As Label
    Friend WithEvents lblZECzcor As Label
    Friend WithEvents lblZECJohn As Label
    Friend WithEvents lblZECjmhoff98 As Label
    Friend WithEvents lblZECRebec As Label
    Friend WithEvents lblZECRebecca As Label
    Friend WithEvents lblZECMark As Label
    Friend WithEvents lblZECmcurry As Label
    Friend WithEvents lblZECBrendan As Label
    Friend WithEvents lblZECbwight4 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
End Class
