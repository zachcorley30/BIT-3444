﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmZECProblem
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblJMHStatement = New System.Windows.Forms.Label()
        Me.lblZECObjective = New System.Windows.Forms.Label()
        Me.lblZECValue = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.gbxZECOutput = New System.Windows.Forms.GroupBox()
        Me.tlpZECOutput = New System.Windows.Forms.TableLayoutPanel()
        Me.lblZECExtra = New System.Windows.Forms.Label()
        Me.rtbZECValuePerformance = New System.Windows.Forms.RichTextBox()
        Me.rtbZECValueObjective = New System.Windows.Forms.RichTextBox()
        Me.rtbZECStatement = New System.Windows.Forms.RichTextBox()
        Me.rtbZECExtra = New System.Windows.Forms.RichTextBox()
        Me.lblBZECTitle = New System.Windows.Forms.Label()
        Me.gbxZECOutput.SuspendLayout()
        Me.tlpZECOutput.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblJMHStatement
        '
        Me.lblJMHStatement.AutoSize = True
        Me.lblJMHStatement.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblJMHStatement.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJMHStatement.Location = New System.Drawing.Point(2, 0)
        Me.lblJMHStatement.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblJMHStatement.Name = "lblJMHStatement"
        Me.lblJMHStatement.Size = New System.Drawing.Size(114, 20)
        Me.lblJMHStatement.TabIndex = 0
        Me.lblJMHStatement.Text = "Statement of DSS"
        '
        'lblZECObjective
        '
        Me.lblZECObjective.AutoSize = True
        Me.lblZECObjective.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECObjective.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECObjective.Location = New System.Drawing.Point(2, 49)
        Me.lblZECObjective.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblZECObjective.Name = "lblZECObjective"
        Me.lblZECObjective.Size = New System.Drawing.Size(137, 20)
        Me.lblZECObjective.TabIndex = 1
        Me.lblZECObjective.Text = "Value of Obj Function"
        '
        'lblZECValue
        '
        Me.lblZECValue.AutoSize = True
        Me.lblZECValue.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECValue.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECValue.Location = New System.Drawing.Point(2, 98)
        Me.lblZECValue.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblZECValue.Name = "lblZECValue"
        Me.lblZECValue.Size = New System.Drawing.Size(202, 40)
        Me.lblZECValue.TabIndex = 2
        Me.lblZECValue.Text = "Value of performance at optimal solution"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Red
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(78, 278)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 17)
        Me.Label3.TabIndex = 3
        '
        'gbxZECOutput
        '
        Me.gbxZECOutput.BackColor = System.Drawing.Color.White
        Me.gbxZECOutput.Controls.Add(Me.tlpZECOutput)
        Me.gbxZECOutput.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxZECOutput.Location = New System.Drawing.Point(30, 87)
        Me.gbxZECOutput.Margin = New System.Windows.Forms.Padding(2)
        Me.gbxZECOutput.Name = "gbxZECOutput"
        Me.gbxZECOutput.Padding = New System.Windows.Forms.Padding(2)
        Me.gbxZECOutput.Size = New System.Drawing.Size(499, 283)
        Me.gbxZECOutput.TabIndex = 4
        Me.gbxZECOutput.TabStop = False
        Me.gbxZECOutput.Text = "Output"
        '
        'tlpZECOutput
        '
        Me.tlpZECOutput.ColumnCount = 2
        Me.tlpZECOutput.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpZECOutput.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpZECOutput.Controls.Add(Me.lblZECExtra, 0, 3)
        Me.tlpZECOutput.Controls.Add(Me.rtbZECValuePerformance, 1, 2)
        Me.tlpZECOutput.Controls.Add(Me.rtbZECValueObjective, 1, 1)
        Me.tlpZECOutput.Controls.Add(Me.lblZECValue, 0, 2)
        Me.tlpZECOutput.Controls.Add(Me.lblZECObjective, 0, 1)
        Me.tlpZECOutput.Controls.Add(Me.lblJMHStatement, 0, 0)
        Me.tlpZECOutput.Controls.Add(Me.rtbZECExtra, 1, 3)
        Me.tlpZECOutput.Controls.Add(Me.rtbZECStatement, 1, 0)
        Me.tlpZECOutput.Location = New System.Drawing.Point(52, 35)
        Me.tlpZECOutput.Margin = New System.Windows.Forms.Padding(2)
        Me.tlpZECOutput.Name = "tlpZECOutput"
        Me.tlpZECOutput.RowCount = 4
        Me.tlpZECOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.22222!))
        Me.tlpZECOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.22222!))
        Me.tlpZECOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.22222!))
        Me.tlpZECOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334!))
        Me.tlpZECOutput.Size = New System.Drawing.Size(412, 223)
        Me.tlpZECOutput.TabIndex = 3
        '
        'lblZECExtra
        '
        Me.lblZECExtra.AutoSize = True
        Me.lblZECExtra.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECExtra.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECExtra.Location = New System.Drawing.Point(2, 147)
        Me.lblZECExtra.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblZECExtra.Name = "lblZECExtra"
        Me.lblZECExtra.Size = New System.Drawing.Size(64, 20)
        Me.lblZECExtra.TabIndex = 6
        Me.lblZECExtra.Text = "Extra Info"
        '
        'rtbZECValuePerformance
        '
        Me.rtbZECValuePerformance.Location = New System.Drawing.Point(208, 100)
        Me.rtbZECValuePerformance.Margin = New System.Windows.Forms.Padding(2)
        Me.rtbZECValuePerformance.Name = "rtbZECValuePerformance"
        Me.rtbZECValuePerformance.Size = New System.Drawing.Size(188, 45)
        Me.rtbZECValuePerformance.TabIndex = 5
        Me.rtbZECValuePerformance.Text = ""
        '
        'rtbZECValueObjective
        '
        Me.rtbZECValueObjective.Location = New System.Drawing.Point(208, 51)
        Me.rtbZECValueObjective.Margin = New System.Windows.Forms.Padding(2)
        Me.rtbZECValueObjective.Name = "rtbZECValueObjective"
        Me.rtbZECValueObjective.Size = New System.Drawing.Size(188, 45)
        Me.rtbZECValueObjective.TabIndex = 4
        Me.rtbZECValueObjective.Text = ""
        '
        'rtbZECStatement
        '
        Me.rtbZECStatement.Location = New System.Drawing.Point(208, 2)
        Me.rtbZECStatement.Margin = New System.Windows.Forms.Padding(2)
        Me.rtbZECStatement.Name = "rtbZECStatement"
        Me.rtbZECStatement.Size = New System.Drawing.Size(188, 45)
        Me.rtbZECStatement.TabIndex = 3
        Me.rtbZECStatement.Text = ""
        '
        'rtbZECExtra
        '
        Me.rtbZECExtra.Location = New System.Drawing.Point(208, 149)
        Me.rtbZECExtra.Margin = New System.Windows.Forms.Padding(2)
        Me.rtbZECExtra.Name = "rtbZECExtra"
        Me.rtbZECExtra.Size = New System.Drawing.Size(188, 52)
        Me.rtbZECExtra.TabIndex = 7
        Me.rtbZECExtra.Text = ""
        '
        'lblBZECTitle
        '
        Me.lblBZECTitle.AutoSize = True
        Me.lblBZECTitle.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBZECTitle.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBZECTitle.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblBZECTitle.Location = New System.Drawing.Point(243, 31)
        Me.lblBZECTitle.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblBZECTitle.Name = "lblBZECTitle"
        Me.lblBZECTitle.Size = New System.Drawing.Size(83, 25)
        Me.lblBZECTitle.TabIndex = 5
        Me.lblBZECTitle.Text = "Solution"
        '
        'frmZECProblem
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Brown
        Me.ClientSize = New System.Drawing.Size(564, 408)
        Me.Controls.Add(Me.lblBZECTitle)
        Me.Controls.Add(Me.gbxZECOutput)
        Me.Controls.Add(Me.Label3)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmZECProblem"
        Me.Text = "Problem"
        Me.gbxZECOutput.ResumeLayout(False)
        Me.tlpZECOutput.ResumeLayout(False)
        Me.tlpZECOutput.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblJMHStatement As Label
    Friend WithEvents lblZECObjective As Label
    Friend WithEvents lblZECValue As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents gbxZECOutput As GroupBox
    Friend WithEvents tlpZECOutput As TableLayoutPanel
    Friend WithEvents rtbZECValuePerformance As RichTextBox
    Friend WithEvents rtbZECValueObjective As RichTextBox
    Friend WithEvents rtbZECStatement As RichTextBox
    Friend WithEvents lblZECExtra As Label
    Friend WithEvents rtbZECExtra As RichTextBox

    Private Sub lblJMHTB1_Click(sender As Object, e As EventArgs) Handles lblJMHStatement.Click

    End Sub

    Private Sub frmZEC_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Friend WithEvents lblBZECTitle As Label
End Class
