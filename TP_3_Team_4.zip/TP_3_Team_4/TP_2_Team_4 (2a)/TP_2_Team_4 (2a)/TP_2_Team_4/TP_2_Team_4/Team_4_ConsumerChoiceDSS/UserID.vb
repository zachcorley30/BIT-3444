﻿'ZEC: This class holds the values for usernames and passwords
Public Class UserID
    Public Shared Property UserIDList As New List(Of UserID)

    Public Property ID As Integer 'MDC: stores the user ID as an integer
    Public Property Username As String 'MDC: stores the user username as a string
    Public Property Password As String 'MDC: stores the user password as a string

    'ZEC: This sub is run whenever an object of the class is created
    Public Sub New()

    End Sub

End Class
