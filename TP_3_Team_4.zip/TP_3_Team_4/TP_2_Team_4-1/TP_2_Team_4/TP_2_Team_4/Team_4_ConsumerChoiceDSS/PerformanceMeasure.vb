﻿'ZEC: This class holds the values for the names of performance measures
Public Class PerformanceMeasure
    Public Shared Property PerformanceMeasureList As New List(Of PerformanceMeasure)

    Public Property PerformanceName As String 'MDC: stores the name of performance measure as a string

    'ZEC: This sub is run whenever an object of the class is created
    Public Sub New()

    End Sub
End Class
