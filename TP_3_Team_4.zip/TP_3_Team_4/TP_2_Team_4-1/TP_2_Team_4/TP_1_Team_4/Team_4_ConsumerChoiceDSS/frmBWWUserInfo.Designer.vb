﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBWWUserInput
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblBWWTitle = New System.Windows.Forms.Label()
        Me.gbxBWWCarData = New System.Windows.Forms.GroupBox()
        Me.lblBWWCarSpecification = New System.Windows.Forms.Label()
        Me.tlpBWWCarInfo = New System.Windows.Forms.TableLayoutPanel()
        Me.lblBWWCarMake = New System.Windows.Forms.Label()
        Me.lblBWWCarModel = New System.Windows.Forms.Label()
        Me.lblBWWCarYear = New System.Windows.Forms.Label()
        Me.lblBWWTransmission = New System.Windows.Forms.Label()
        Me.txtBWWCarYear = New System.Windows.Forms.TextBox()
        Me.cbxBWWTransmission = New System.Windows.Forms.ComboBox()
        Me.cbxBWWCarMake = New System.Windows.Forms.ComboBox()
        Me.cbxBWWCarModel = New System.Windows.Forms.ComboBox()
        Me.btnBWWSolve = New System.Windows.Forms.Button()
        Me.rtbBWWSolution = New System.Windows.Forms.RichTextBox()
        Me.gbxBWWCarData.SuspendLayout()
        Me.tlpBWWCarInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblBWWTitle
        '
        Me.lblBWWTitle.AutoSize = True
        Me.lblBWWTitle.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWTitle.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWTitle.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblBWWTitle.Location = New System.Drawing.Point(268, 17)
        Me.lblBWWTitle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBWWTitle.Name = "lblBWWTitle"
        Me.lblBWWTitle.Size = New System.Drawing.Size(791, 49)
        Me.lblBWWTitle.TabIndex = 0
        Me.lblBWWTitle.Text = "What type of vehicle do you want to purchase?"
        '
        'gbxBWWCarData
        '
        Me.gbxBWWCarData.BackColor = System.Drawing.Color.Snow
        Me.gbxBWWCarData.Controls.Add(Me.lblBWWCarSpecification)
        Me.gbxBWWCarData.Controls.Add(Me.tlpBWWCarInfo)
        Me.gbxBWWCarData.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxBWWCarData.Location = New System.Drawing.Point(52, 92)
        Me.gbxBWWCarData.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbxBWWCarData.Name = "gbxBWWCarData"
        Me.gbxBWWCarData.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbxBWWCarData.Size = New System.Drawing.Size(732, 512)
        Me.gbxBWWCarData.TabIndex = 1
        Me.gbxBWWCarData.TabStop = False
        Me.gbxBWWCarData.Text = "Car Data"
        '
        'lblBWWCarSpecification
        '
        Me.lblBWWCarSpecification.AutoSize = True
        Me.lblBWWCarSpecification.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWCarSpecification.Font = New System.Drawing.Font("Arial Narrow", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWCarSpecification.Location = New System.Drawing.Point(22, 63)
        Me.lblBWWCarSpecification.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBWWCarSpecification.Name = "lblBWWCarSpecification"
        Me.lblBWWCarSpecification.Size = New System.Drawing.Size(518, 37)
        Me.lblBWWCarSpecification.TabIndex = 1
        Me.lblBWWCarSpecification.Text = "What car specifications do you require?"
        '
        'tlpBWWCarInfo
        '
        Me.tlpBWWCarInfo.ColumnCount = 2
        Me.tlpBWWCarInfo.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpBWWCarInfo.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpBWWCarInfo.Controls.Add(Me.lblBWWCarMake, 0, 0)
        Me.tlpBWWCarInfo.Controls.Add(Me.lblBWWCarModel, 0, 1)
        Me.tlpBWWCarInfo.Controls.Add(Me.lblBWWCarYear, 0, 2)
        Me.tlpBWWCarInfo.Controls.Add(Me.lblBWWTransmission, 0, 3)
        Me.tlpBWWCarInfo.Controls.Add(Me.txtBWWCarYear, 1, 2)
        Me.tlpBWWCarInfo.Controls.Add(Me.cbxBWWTransmission, 1, 3)
        Me.tlpBWWCarInfo.Controls.Add(Me.cbxBWWCarMake, 1, 0)
        Me.tlpBWWCarInfo.Controls.Add(Me.cbxBWWCarModel, 1, 1)
        Me.tlpBWWCarInfo.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlpBWWCarInfo.Location = New System.Drawing.Point(30, 140)
        Me.tlpBWWCarInfo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.tlpBWWCarInfo.Name = "tlpBWWCarInfo"
        Me.tlpBWWCarInfo.RowCount = 4
        Me.tlpBWWCarInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpBWWCarInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpBWWCarInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpBWWCarInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpBWWCarInfo.Size = New System.Drawing.Size(522, 296)
        Me.tlpBWWCarInfo.TabIndex = 0
        '
        'lblBWWCarMake
        '
        Me.lblBWWCarMake.AutoSize = True
        Me.lblBWWCarMake.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWCarMake.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWCarMake.Location = New System.Drawing.Point(2, 0)
        Me.lblBWWCarMake.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBWWCarMake.Name = "lblBWWCarMake"
        Me.lblBWWCarMake.Size = New System.Drawing.Size(132, 37)
        Me.lblBWWCarMake.TabIndex = 0
        Me.lblBWWCarMake.Text = "Car Make"
        '
        'lblBWWCarModel
        '
        Me.lblBWWCarModel.AutoSize = True
        Me.lblBWWCarModel.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWCarModel.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWCarModel.Location = New System.Drawing.Point(2, 74)
        Me.lblBWWCarModel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBWWCarModel.Name = "lblBWWCarModel"
        Me.lblBWWCarModel.Size = New System.Drawing.Size(140, 37)
        Me.lblBWWCarModel.TabIndex = 1
        Me.lblBWWCarModel.Text = "Car Model"
        '
        'lblBWWCarYear
        '
        Me.lblBWWCarYear.AutoSize = True
        Me.lblBWWCarYear.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWCarYear.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWCarYear.Location = New System.Drawing.Point(2, 148)
        Me.lblBWWCarYear.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBWWCarYear.Name = "lblBWWCarYear"
        Me.lblBWWCarYear.Size = New System.Drawing.Size(124, 37)
        Me.lblBWWCarYear.TabIndex = 2
        Me.lblBWWCarYear.Text = "Car Year"
        '
        'lblBWWTransmission
        '
        Me.lblBWWTransmission.AutoSize = True
        Me.lblBWWTransmission.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWTransmission.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWTransmission.Location = New System.Drawing.Point(2, 222)
        Me.lblBWWTransmission.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBWWTransmission.Name = "lblBWWTransmission"
        Me.lblBWWTransmission.Size = New System.Drawing.Size(175, 37)
        Me.lblBWWTransmission.TabIndex = 3
        Me.lblBWWTransmission.Text = "Transmission"
        '
        'txtBWWCarYear
        '
        Me.txtBWWCarYear.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBWWCarYear.Location = New System.Drawing.Point(263, 150)
        Me.txtBWWCarYear.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtBWWCarYear.Name = "txtBWWCarYear"
        Me.txtBWWCarYear.Size = New System.Drawing.Size(254, 33)
        Me.txtBWWCarYear.TabIndex = 4
        '
        'cbxBWWTransmission
        '
        Me.cbxBWWTransmission.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxBWWTransmission.FormattingEnabled = True
        Me.cbxBWWTransmission.Location = New System.Drawing.Point(263, 224)
        Me.cbxBWWTransmission.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.cbxBWWTransmission.Name = "cbxBWWTransmission"
        Me.cbxBWWTransmission.Size = New System.Drawing.Size(254, 34)
        Me.cbxBWWTransmission.TabIndex = 5
        '
        'cbxBWWCarMake
        '
        Me.cbxBWWCarMake.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxBWWCarMake.FormattingEnabled = True
        Me.cbxBWWCarMake.Location = New System.Drawing.Point(263, 2)
        Me.cbxBWWCarMake.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.cbxBWWCarMake.Name = "cbxBWWCarMake"
        Me.cbxBWWCarMake.Size = New System.Drawing.Size(254, 34)
        Me.cbxBWWCarMake.TabIndex = 6
        '
        'cbxBWWCarModel
        '
        Me.cbxBWWCarModel.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxBWWCarModel.FormattingEnabled = True
        Me.cbxBWWCarModel.Location = New System.Drawing.Point(263, 76)
        Me.cbxBWWCarModel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.cbxBWWCarModel.Name = "cbxBWWCarModel"
        Me.cbxBWWCarModel.Size = New System.Drawing.Size(254, 34)
        Me.cbxBWWCarModel.TabIndex = 7
        '
        'btnBWWSolve
        '
        Me.btnBWWSolve.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBWWSolve.Location = New System.Drawing.Point(994, 198)
        Me.btnBWWSolve.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnBWWSolve.Name = "btnBWWSolve"
        Me.btnBWWSolve.Size = New System.Drawing.Size(196, 77)
        Me.btnBWWSolve.TabIndex = 2
        Me.btnBWWSolve.Text = "Solve"
        Me.btnBWWSolve.UseVisualStyleBackColor = True
        '
        'rtbBWWSolution
        '
        Me.rtbBWWSolution.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbBWWSolution.Location = New System.Drawing.Point(994, 312)
        Me.rtbBWWSolution.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.rtbBWWSolution.Name = "rtbBWWSolution"
        Me.rtbBWWSolution.Size = New System.Drawing.Size(196, 191)
        Me.rtbBWWSolution.TabIndex = 3
        Me.rtbBWWSolution.Text = ""
        '
        'frmBWWUserInput
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1382, 721)
        Me.Controls.Add(Me.rtbBWWSolution)
        Me.Controls.Add(Me.btnBWWSolve)
        Me.Controls.Add(Me.gbxBWWCarData)
        Me.Controls.Add(Me.lblBWWTitle)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmBWWUserInput"
        Me.Text = "User Input"
        Me.gbxBWWCarData.ResumeLayout(False)
        Me.gbxBWWCarData.PerformLayout()
        Me.tlpBWWCarInfo.ResumeLayout(False)
        Me.tlpBWWCarInfo.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBWWTitle As Label
    Friend WithEvents gbxBWWCarData As GroupBox
    Friend WithEvents lblBWWCarSpecification As Label
    Friend WithEvents tlpBWWCarInfo As TableLayoutPanel
    Friend WithEvents lblBWWCarMake As Label
    Friend WithEvents lblBWWCarModel As Label
    Friend WithEvents lblBWWCarYear As Label
    Friend WithEvents lblBWWTransmission As Label
    Friend WithEvents txtBWWCarYear As TextBox
    Friend WithEvents cbxBWWTransmission As ComboBox
    Friend WithEvents cbxBWWCarMake As ComboBox
    Friend WithEvents cbxBWWCarModel As ComboBox
    Friend WithEvents btnBWWSolve As Button
    Friend WithEvents rtbBWWSolution As RichTextBox
End Class
