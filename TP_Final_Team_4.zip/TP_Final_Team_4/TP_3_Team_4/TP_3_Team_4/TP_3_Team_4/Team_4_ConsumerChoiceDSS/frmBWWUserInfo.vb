﻿Public Class frmBWWUserInput
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblBWWTitle.Click

    End Sub

    Private Sub gbxBWWCarData_Enter(sender As Object, e As EventArgs) Handles gbxBWWCarData.Enter

    End Sub

    Private Sub btnBWWSolve_Click(sender As Object, e As EventArgs) Handles btnBWWSolve.Click

        'RMD: when the user clicks the solve button, opens form with formatted table with optimal solution


    End Sub
End Class