﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmZECWelcome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblZECWelcome = New System.Windows.Forms.Label()
        Me.lblZECUsername = New System.Windows.Forms.Label()
        Me.lblZECPassword = New System.Windows.Forms.Label()
        Me.txtZECUsername = New System.Windows.Forms.TextBox()
        Me.txtZECPassword = New System.Windows.Forms.TextBox()
        Me.lblZECLogin = New System.Windows.Forms.Label()
        Me.btnZECExit = New System.Windows.Forms.Button()
        Me.btnZECEnter = New System.Windows.Forms.Button()
        Me.gbxZECLogin = New System.Windows.Forms.GroupBox()
        Me.pbxZECLogo = New System.Windows.Forms.PictureBox()
        Me.btnZECToUser = New System.Windows.Forms.Button()
        Me.btnZECToTeam = New System.Windows.Forms.Button()
        Me.btnZECToProblem = New System.Windows.Forms.Button()
        Me.btnZECtoHelp = New System.Windows.Forms.Button()
        Me.btnZECToData = New System.Windows.Forms.Button()
        Me.gbxZECLogin.SuspendLayout()
        CType(Me.pbxZECLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblZECWelcome
        '
        Me.lblZECWelcome.AutoSize = True
        Me.lblZECWelcome.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECWelcome.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECWelcome.Location = New System.Drawing.Point(464, 17)
        Me.lblZECWelcome.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECWelcome.Name = "lblZECWelcome"
        Me.lblZECWelcome.Size = New System.Drawing.Size(174, 49)
        Me.lblZECWelcome.TabIndex = 0
        Me.lblZECWelcome.Text = "Welcome"
        '
        'lblZECUsername
        '
        Me.lblZECUsername.AutoSize = True
        Me.lblZECUsername.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECUsername.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECUsername.Location = New System.Drawing.Point(86, 165)
        Me.lblZECUsername.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECUsername.Name = "lblZECUsername"
        Me.lblZECUsername.Size = New System.Drawing.Size(140, 37)
        Me.lblZECUsername.TabIndex = 0
        Me.lblZECUsername.Text = "Username"
        '
        'lblZECPassword
        '
        Me.lblZECPassword.AutoSize = True
        Me.lblZECPassword.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECPassword.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECPassword.Location = New System.Drawing.Point(86, 248)
        Me.lblZECPassword.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECPassword.Name = "lblZECPassword"
        Me.lblZECPassword.Size = New System.Drawing.Size(134, 37)
        Me.lblZECPassword.TabIndex = 1
        Me.lblZECPassword.Text = "Password"
        '
        'txtZECUsername
        '
        Me.txtZECUsername.Location = New System.Drawing.Point(278, 167)
        Me.txtZECUsername.Margin = New System.Windows.Forms.Padding(6)
        Me.txtZECUsername.Name = "txtZECUsername"
        Me.txtZECUsername.Size = New System.Drawing.Size(188, 33)
        Me.txtZECUsername.TabIndex = 2
        '
        'txtZECPassword
        '
        Me.txtZECPassword.Location = New System.Drawing.Point(278, 248)
        Me.txtZECPassword.Margin = New System.Windows.Forms.Padding(6)
        Me.txtZECPassword.Name = "txtZECPassword"
        Me.txtZECPassword.Size = New System.Drawing.Size(188, 33)
        Me.txtZECPassword.TabIndex = 3
        '
        'lblZECLogin
        '
        Me.lblZECLogin.AutoSize = True
        Me.lblZECLogin.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECLogin.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECLogin.Location = New System.Drawing.Point(270, 48)
        Me.lblZECLogin.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECLogin.Name = "lblZECLogin"
        Me.lblZECLogin.Size = New System.Drawing.Size(94, 44)
        Me.lblZECLogin.TabIndex = 4
        Me.lblZECLogin.Text = "Login"
        '
        'btnZECExit
        '
        Me.btnZECExit.Location = New System.Drawing.Point(291, 356)
        Me.btnZECExit.Margin = New System.Windows.Forms.Padding(6)
        Me.btnZECExit.Name = "btnZECExit"
        Me.btnZECExit.Size = New System.Drawing.Size(152, 56)
        Me.btnZECExit.TabIndex = 5
        Me.btnZECExit.Text = "Exit"
        Me.btnZECExit.UseVisualStyleBackColor = True
        '
        'btnZECEnter
        '
        Me.btnZECEnter.Location = New System.Drawing.Point(74, 356)
        Me.btnZECEnter.Margin = New System.Windows.Forms.Padding(6)
        Me.btnZECEnter.Name = "btnZECEnter"
        Me.btnZECEnter.Size = New System.Drawing.Size(152, 56)
        Me.btnZECEnter.TabIndex = 6
        Me.btnZECEnter.Text = "Enter"
        Me.btnZECEnter.UseVisualStyleBackColor = True
        '
        'gbxZECLogin
        '
        Me.gbxZECLogin.BackColor = System.Drawing.Color.Snow
        Me.gbxZECLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.gbxZECLogin.Controls.Add(Me.pbxZECLogo)
        Me.gbxZECLogin.Controls.Add(Me.btnZECEnter)
        Me.gbxZECLogin.Controls.Add(Me.btnZECExit)
        Me.gbxZECLogin.Controls.Add(Me.lblZECLogin)
        Me.gbxZECLogin.Controls.Add(Me.txtZECPassword)
        Me.gbxZECLogin.Controls.Add(Me.txtZECUsername)
        Me.gbxZECLogin.Controls.Add(Me.lblZECPassword)
        Me.gbxZECLogin.Controls.Add(Me.lblZECUsername)
        Me.gbxZECLogin.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxZECLogin.Location = New System.Drawing.Point(110, 98)
        Me.gbxZECLogin.Margin = New System.Windows.Forms.Padding(6)
        Me.gbxZECLogin.Name = "gbxZECLogin"
        Me.gbxZECLogin.Padding = New System.Windows.Forms.Padding(6)
        Me.gbxZECLogin.Size = New System.Drawing.Size(842, 446)
        Me.gbxZECLogin.TabIndex = 1
        Me.gbxZECLogin.TabStop = False
        Me.gbxZECLogin.Text = "User Login"
        '
        'pbxZECLogo
        '
        Me.pbxZECLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbxZECLogo.Image = Global.Team_4_ConsumerChoiceDSS.My.Resources.Resources.CDHW__1_
        Me.pbxZECLogo.Location = New System.Drawing.Point(528, 77)
        Me.pbxZECLogo.Margin = New System.Windows.Forms.Padding(6)
        Me.pbxZECLogo.Name = "pbxZECLogo"
        Me.pbxZECLogo.Size = New System.Drawing.Size(268, 279)
        Me.pbxZECLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbxZECLogo.TabIndex = 8
        Me.pbxZECLogo.TabStop = False
        '
        'btnZECToUser
        '
        Me.btnZECToUser.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnZECToUser.Location = New System.Drawing.Point(56, 619)
        Me.btnZECToUser.Margin = New System.Windows.Forms.Padding(6)
        Me.btnZECToUser.Name = "btnZECToUser"
        Me.btnZECToUser.Size = New System.Drawing.Size(152, 56)
        Me.btnZECToUser.TabIndex = 6
        Me.btnZECToUser.Text = "To User Info"
        Me.btnZECToUser.UseVisualStyleBackColor = True
        '
        'btnZECToTeam
        '
        Me.btnZECToTeam.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnZECToTeam.Location = New System.Drawing.Point(655, 619)
        Me.btnZECToTeam.Margin = New System.Windows.Forms.Padding(6)
        Me.btnZECToTeam.Name = "btnZECToTeam"
        Me.btnZECToTeam.Size = New System.Drawing.Size(152, 56)
        Me.btnZECToTeam.TabIndex = 7
        Me.btnZECToTeam.Text = "To Team"
        Me.btnZECToTeam.UseVisualStyleBackColor = True
        '
        'btnZECToProblem
        '
        Me.btnZECToProblem.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnZECToProblem.Location = New System.Drawing.Point(257, 619)
        Me.btnZECToProblem.Margin = New System.Windows.Forms.Padding(6)
        Me.btnZECToProblem.Name = "btnZECToProblem"
        Me.btnZECToProblem.Size = New System.Drawing.Size(152, 56)
        Me.btnZECToProblem.TabIndex = 8
        Me.btnZECToProblem.Text = "To Problem"
        Me.btnZECToProblem.UseVisualStyleBackColor = True
        '
        'btnZECtoHelp
        '
        Me.btnZECtoHelp.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnZECtoHelp.Location = New System.Drawing.Point(860, 619)
        Me.btnZECtoHelp.Margin = New System.Windows.Forms.Padding(6)
        Me.btnZECtoHelp.Name = "btnZECtoHelp"
        Me.btnZECtoHelp.Size = New System.Drawing.Size(152, 56)
        Me.btnZECtoHelp.TabIndex = 9
        Me.btnZECtoHelp.Text = "To Help"
        Me.btnZECtoHelp.UseVisualStyleBackColor = True
        '
        'btnZECToData
        '
        Me.btnZECToData.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnZECToData.Location = New System.Drawing.Point(456, 619)
        Me.btnZECToData.Margin = New System.Windows.Forms.Padding(6)
        Me.btnZECToData.Name = "btnZECToData"
        Me.btnZECToData.Size = New System.Drawing.Size(152, 56)
        Me.btnZECToData.TabIndex = 10
        Me.btnZECToData.Text = "To Data"
        Me.btnZECToData.UseVisualStyleBackColor = True
        '
        'frmZECWelcome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1086, 746)
        Me.Controls.Add(Me.btnZECToData)
        Me.Controls.Add(Me.btnZECtoHelp)
        Me.Controls.Add(Me.btnZECToProblem)
        Me.Controls.Add(Me.btnZECToTeam)
        Me.Controls.Add(Me.btnZECToUser)
        Me.Controls.Add(Me.gbxZECLogin)
        Me.Controls.Add(Me.lblZECWelcome)
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.Name = "frmZECWelcome"
        Me.Text = "Welcome"
        Me.gbxZECLogin.ResumeLayout(False)
        Me.gbxZECLogin.PerformLayout()
        CType(Me.pbxZECLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblZECWelcome As Label
    Friend WithEvents lblZECUsername As Label
    Friend WithEvents lblZECPassword As Label
    Friend WithEvents txtZECUsername As TextBox
    Friend WithEvents txtZECPassword As TextBox
    Friend WithEvents lblZECLogin As Label
    Friend WithEvents btnZECExit As Button
    Friend WithEvents btnZECEnter As Button
    Friend WithEvents gbxZECLogin As GroupBox
    Friend WithEvents pbxZECLogo As PictureBox

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles pbxZECLogo.Click

    End Sub

    Private Sub frmZECWelcome_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnZECToData.Hide()
        btnZECToUser.Hide()
        btnZECToProblem.Hide()
    End Sub

    Friend WithEvents btnZECToUser As Button
    Friend WithEvents btnZECToTeam As Button
    Friend WithEvents btnZECToProblem As Button
    Friend WithEvents btnZECtoHelp As Button
    Friend WithEvents btnZECToData As Button
End Class
