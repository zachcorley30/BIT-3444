﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formBWWUserInput
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblBWWTitle = New System.Windows.Forms.Label()
        Me.gbxBWWCarData = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtBWWCarYear = New System.Windows.Forms.TextBox()
        Me.cbxBWWTransmission = New System.Windows.Forms.ComboBox()
        Me.cbxBWWCarMake = New System.Windows.Forms.ComboBox()
        Me.cbxBWWCarModel = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnBWWSolve = New System.Windows.Forms.Button()
        Me.rtbBWWSolution = New System.Windows.Forms.RichTextBox()
        Me.gbxBWWCarData.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblBWWTitle
        '
        Me.lblBWWTitle.AutoSize = True
        Me.lblBWWTitle.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWTitle.Font = New System.Drawing.Font("Microsoft Yi Baiti", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWTitle.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblBWWTitle.Location = New System.Drawing.Point(225, 31)
        Me.lblBWWTitle.Name = "lblBWWTitle"
        Me.lblBWWTitle.Size = New System.Drawing.Size(995, 54)
        Me.lblBWWTitle.TabIndex = 0
        Me.lblBWWTitle.Text = "What type of vehicle do you want to purchase?"
        '
        'gbxBWWCarData
        '
        Me.gbxBWWCarData.BackColor = System.Drawing.Color.Brown
        Me.gbxBWWCarData.Controls.Add(Me.Label5)
        Me.gbxBWWCarData.Controls.Add(Me.TableLayoutPanel1)
        Me.gbxBWWCarData.Location = New System.Drawing.Point(70, 115)
        Me.gbxBWWCarData.Name = "gbxBWWCarData"
        Me.gbxBWWCarData.Size = New System.Drawing.Size(819, 635)
        Me.gbxBWWCarData.TabIndex = 1
        Me.gbxBWWCarData.TabStop = False
        Me.gbxBWWCarData.Text = "Car Data"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtBWWCarYear, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.cbxBWWTransmission, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.cbxBWWCarMake, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.cbxBWWCarModel, 1, 1)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(38, 228)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(695, 368)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(192, 46)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Car Make"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(204, 46)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Car Model"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 184)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(178, 46)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Car Year"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(3, 276)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(257, 46)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Transmission"
        '
        'txtBWWCarYear
        '
        Me.txtBWWCarYear.Location = New System.Drawing.Point(350, 187)
        Me.txtBWWCarYear.Name = "txtBWWCarYear"
        Me.txtBWWCarYear.Size = New System.Drawing.Size(342, 38)
        Me.txtBWWCarYear.TabIndex = 4
        '
        'cbxBWWTransmission
        '
        Me.cbxBWWTransmission.FormattingEnabled = True
        Me.cbxBWWTransmission.Location = New System.Drawing.Point(350, 279)
        Me.cbxBWWTransmission.Name = "cbxBWWTransmission"
        Me.cbxBWWTransmission.Size = New System.Drawing.Size(342, 39)
        Me.cbxBWWTransmission.TabIndex = 5
        '
        'cbxBWWCarMake
        '
        Me.cbxBWWCarMake.FormattingEnabled = True
        Me.cbxBWWCarMake.Location = New System.Drawing.Point(350, 3)
        Me.cbxBWWCarMake.Name = "cbxBWWCarMake"
        Me.cbxBWWCarMake.Size = New System.Drawing.Size(342, 39)
        Me.cbxBWWCarMake.TabIndex = 6
        '
        'cbxBWWCarModel
        '
        Me.cbxBWWCarModel.FormattingEnabled = True
        Me.cbxBWWCarModel.Location = New System.Drawing.Point(350, 95)
        Me.cbxBWWCarModel.Name = "cbxBWWCarModel"
        Me.cbxBWWCarModel.Size = New System.Drawing.Size(342, 39)
        Me.cbxBWWCarModel.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Label5.Font = New System.Drawing.Font("Microsoft YaHei Light", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(29, 79)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(772, 52)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "What car specifications do you require?"
        '
        'btnBWWSolve
        '
        Me.btnBWWSolve.Font = New System.Drawing.Font("Microsoft YaHei Light", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBWWSolve.Location = New System.Drawing.Point(1051, 245)
        Me.btnBWWSolve.Name = "btnBWWSolve"
        Me.btnBWWSolve.Size = New System.Drawing.Size(260, 96)
        Me.btnBWWSolve.TabIndex = 2
        Me.btnBWWSolve.Text = "Solve"
        Me.btnBWWSolve.UseVisualStyleBackColor = True
        '
        'rtbBWWSolution
        '
        Me.rtbBWWSolution.Location = New System.Drawing.Point(1051, 377)
        Me.rtbBWWSolution.Name = "rtbBWWSolution"
        Me.rtbBWWSolution.Size = New System.Drawing.Size(260, 235)
        Me.rtbBWWSolution.TabIndex = 3
        Me.rtbBWWSolution.Text = ""
        '
        'formBWWUserInput
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(16.0!, 31.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Brown
        Me.ClientSize = New System.Drawing.Size(1468, 912)
        Me.Controls.Add(Me.rtbBWWSolution)
        Me.Controls.Add(Me.btnBWWSolve)
        Me.Controls.Add(Me.gbxBWWCarData)
        Me.Controls.Add(Me.lblBWWTitle)
        Me.Name = "formBWWUserInput"
        Me.Text = "User Input"
        Me.gbxBWWCarData.ResumeLayout(False)
        Me.gbxBWWCarData.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBWWTitle As Label
    Friend WithEvents gbxBWWCarData As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtBWWCarYear As TextBox
    Friend WithEvents cbxBWWTransmission As ComboBox
    Friend WithEvents cbxBWWCarMake As ComboBox
    Friend WithEvents cbxBWWCarModel As ComboBox
    Friend WithEvents btnBWWSolve As Button
    Friend WithEvents rtbBWWSolution As RichTextBox
End Class
