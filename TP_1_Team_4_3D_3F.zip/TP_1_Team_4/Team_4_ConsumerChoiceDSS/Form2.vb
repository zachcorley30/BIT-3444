﻿Public Class formBWWUserInput
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblBWWTitle.Click

    End Sub
End Class