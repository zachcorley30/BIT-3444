﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmZECTeamMembers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmZECTeamMembers))
        Me.lblZECTeam = New System.Windows.Forms.Label()
        Me.lblZECZach = New System.Windows.Forms.Label()
        Me.lblZECzcor = New System.Windows.Forms.Label()
        Me.lblZECJohn = New System.Windows.Forms.Label()
        Me.lblZECjmhoff98 = New System.Windows.Forms.Label()
        Me.lblZECRebec = New System.Windows.Forms.Label()
        Me.lblZECRebecca = New System.Windows.Forms.Label()
        Me.lblZECMark = New System.Windows.Forms.Label()
        Me.lblZECmcurry = New System.Windows.Forms.Label()
        Me.lblZECBrendan = New System.Windows.Forms.Label()
        Me.lblZECbwight4 = New System.Windows.Forms.Label()
        Me.pbxMDCJohn = New System.Windows.Forms.PictureBox()
        Me.pbxMDCZach = New System.Windows.Forms.PictureBox()
        Me.pbxMDCMark = New System.Windows.Forms.PictureBox()
        Me.pbxMDCRebecca = New System.Windows.Forms.PictureBox()
        Me.pbxMDCBrendan = New System.Windows.Forms.PictureBox()
        CType(Me.pbxMDCJohn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxMDCZach, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxMDCMark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxMDCRebecca, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxMDCBrendan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblZECTeam
        '
        Me.lblZECTeam.AutoSize = True
        Me.lblZECTeam.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECTeam.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECTeam.Location = New System.Drawing.Point(740, 17)
        Me.lblZECTeam.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECTeam.Name = "lblZECTeam"
        Me.lblZECTeam.Size = New System.Drawing.Size(141, 49)
        Me.lblZECTeam.TabIndex = 1
        Me.lblZECTeam.Text = "Team 4"
        '
        'lblZECZach
        '
        Me.lblZECZach.AutoSize = True
        Me.lblZECZach.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECZach.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECZach.Location = New System.Drawing.Point(152, 371)
        Me.lblZECZach.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECZach.Name = "lblZECZach"
        Me.lblZECZach.Size = New System.Drawing.Size(168, 37)
        Me.lblZECZach.TabIndex = 2
        Me.lblZECZach.Text = "Zach Corley"
        '
        'lblZECzcor
        '
        Me.lblZECzcor.AutoSize = True
        Me.lblZECzcor.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECzcor.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECzcor.Location = New System.Drawing.Point(144, 425)
        Me.lblZECzcor.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECzcor.Name = "lblZECzcor"
        Me.lblZECzcor.Size = New System.Drawing.Size(175, 37)
        Me.lblZECzcor.TabIndex = 3
        Me.lblZECzcor.Text = "zcor@vt.edu"
        '
        'lblZECJohn
        '
        Me.lblZECJohn.AutoSize = True
        Me.lblZECJohn.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECJohn.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECJohn.Location = New System.Drawing.Point(430, 671)
        Me.lblZECJohn.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECJohn.Name = "lblZECJohn"
        Me.lblZECJohn.Size = New System.Drawing.Size(194, 37)
        Me.lblZECJohn.TabIndex = 4
        Me.lblZECJohn.Text = "John Hoffman"
        '
        'lblZECjmhoff98
        '
        Me.lblZECjmhoff98.AutoSize = True
        Me.lblZECjmhoff98.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECjmhoff98.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECjmhoff98.Location = New System.Drawing.Point(414, 725)
        Me.lblZECjmhoff98.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECjmhoff98.Name = "lblZECjmhoff98"
        Me.lblZECjmhoff98.Size = New System.Drawing.Size(231, 37)
        Me.lblZECjmhoff98.TabIndex = 5
        Me.lblZECjmhoff98.Text = "jmhoff98@vt.edu"
        '
        'lblZECRebec
        '
        Me.lblZECRebec.AutoSize = True
        Me.lblZECRebec.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECRebec.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECRebec.Location = New System.Drawing.Point(714, 425)
        Me.lblZECRebec.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECRebec.Name = "lblZECRebec"
        Me.lblZECRebec.Size = New System.Drawing.Size(222, 37)
        Me.lblZECRebec.TabIndex = 6
        Me.lblZECRebec.Text = "rebec98@vt.edu"
        '
        'lblZECRebecca
        '
        Me.lblZECRebecca.AutoSize = True
        Me.lblZECRebecca.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECRebecca.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECRebecca.Location = New System.Drawing.Point(714, 371)
        Me.lblZECRebecca.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECRebecca.Name = "lblZECRebecca"
        Me.lblZECRebecca.Size = New System.Drawing.Size(225, 37)
        Me.lblZECRebecca.TabIndex = 7
        Me.lblZECRebecca.Text = "Rebecca Dryden"
        '
        'lblZECMark
        '
        Me.lblZECMark.AutoSize = True
        Me.lblZECMark.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECMark.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECMark.Location = New System.Drawing.Point(1326, 371)
        Me.lblZECMark.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECMark.Name = "lblZECMark"
        Me.lblZECMark.Size = New System.Drawing.Size(156, 37)
        Me.lblZECMark.TabIndex = 8
        Me.lblZECMark.Text = "Mark Curry"
        '
        'lblZECmcurry
        '
        Me.lblZECmcurry.AutoSize = True
        Me.lblZECmcurry.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECmcurry.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECmcurry.Location = New System.Drawing.Point(1288, 425)
        Me.lblZECmcurry.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECmcurry.Name = "lblZECmcurry"
        Me.lblZECmcurry.Size = New System.Drawing.Size(240, 37)
        Me.lblZECmcurry.TabIndex = 9
        Me.lblZECmcurry.Text = "mcurry16@vt.edu"
        '
        'lblZECBrendan
        '
        Me.lblZECBrendan.AutoSize = True
        Me.lblZECBrendan.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECBrendan.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECBrendan.Location = New System.Drawing.Point(1048, 671)
        Me.lblZECBrendan.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECBrendan.Name = "lblZECBrendan"
        Me.lblZECBrendan.Size = New System.Drawing.Size(204, 37)
        Me.lblZECBrendan.TabIndex = 10
        Me.lblZECBrendan.Text = "Brendan Wight"
        '
        'lblZECbwight4
        '
        Me.lblZECbwight4.AutoSize = True
        Me.lblZECbwight4.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECbwight4.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECbwight4.Location = New System.Drawing.Point(1048, 723)
        Me.lblZECbwight4.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECbwight4.Name = "lblZECbwight4"
        Me.lblZECbwight4.Size = New System.Drawing.Size(220, 37)
        Me.lblZECbwight4.TabIndex = 11
        Me.lblZECbwight4.Text = "bwight4@vt.edu"
        '
        'pbxMDCJohn
        '
        Me.pbxMDCJohn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pbxMDCJohn.Image = CType(resources.GetObject("pbxMDCJohn.Image"), System.Drawing.Image)
        Me.pbxMDCJohn.Location = New System.Drawing.Point(422, 338)
        Me.pbxMDCJohn.Margin = New System.Windows.Forms.Padding(4)
        Me.pbxMDCJohn.Name = "pbxMDCJohn"
        Me.pbxMDCJohn.Size = New System.Drawing.Size(208, 306)
        Me.pbxMDCJohn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbxMDCJohn.TabIndex = 12
        Me.pbxMDCJohn.TabStop = False
        '
        'pbxMDCZach
        '
        Me.pbxMDCZach.Image = CType(resources.GetObject("pbxMDCZach.Image"), System.Drawing.Image)
        Me.pbxMDCZach.Location = New System.Drawing.Point(119, 55)
        Me.pbxMDCZach.Margin = New System.Windows.Forms.Padding(6)
        Me.pbxMDCZach.Name = "pbxMDCZach"
        Me.pbxMDCZach.Size = New System.Drawing.Size(238, 310)
        Me.pbxMDCZach.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbxMDCZach.TabIndex = 13
        Me.pbxMDCZach.TabStop = False
        '
        'pbxMDCMark
        '
        Me.pbxMDCMark.Image = CType(resources.GetObject("pbxMDCMark.Image"), System.Drawing.Image)
        Me.pbxMDCMark.Location = New System.Drawing.Point(1316, 58)
        Me.pbxMDCMark.Name = "pbxMDCMark"
        Me.pbxMDCMark.Size = New System.Drawing.Size(184, 280)
        Me.pbxMDCMark.TabIndex = 14
        Me.pbxMDCMark.TabStop = False
        '
        'pbxMDCRebecca
        '
        Me.pbxMDCRebecca.Image = CType(resources.GetObject("pbxMDCRebecca.Image"), System.Drawing.Image)
        Me.pbxMDCRebecca.Location = New System.Drawing.Point(721, 82)
        Me.pbxMDCRebecca.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.pbxMDCRebecca.Name = "pbxMDCRebecca"
        Me.pbxMDCRebecca.Size = New System.Drawing.Size(214, 256)
        Me.pbxMDCRebecca.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxMDCRebecca.TabIndex = 15
        Me.pbxMDCRebecca.TabStop = False
        '
        'pbxMDCBrendan
        '
        Me.pbxMDCBrendan.Image = CType(resources.GetObject("pbxMDCBrendan.Image"), System.Drawing.Image)
        Me.pbxMDCBrendan.Location = New System.Drawing.Point(1025, 409)
        Me.pbxMDCBrendan.Name = "pbxMDCBrendan"
        Me.pbxMDCBrendan.Size = New System.Drawing.Size(243, 235)
        Me.pbxMDCBrendan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbxMDCBrendan.TabIndex = 16
        Me.pbxMDCBrendan.TabStop = False
        '
        'frmZECTeamMembers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1600, 865)
        Me.Controls.Add(Me.pbxMDCBrendan)
        Me.Controls.Add(Me.pbxMDCRebecca)
        Me.Controls.Add(Me.pbxMDCMark)
        Me.Controls.Add(Me.pbxMDCZach)
        Me.Controls.Add(Me.pbxMDCJohn)
        Me.Controls.Add(Me.lblZECbwight4)
        Me.Controls.Add(Me.lblZECBrendan)
        Me.Controls.Add(Me.lblZECmcurry)
        Me.Controls.Add(Me.lblZECMark)
        Me.Controls.Add(Me.lblZECRebecca)
        Me.Controls.Add(Me.lblZECRebec)
        Me.Controls.Add(Me.lblZECjmhoff98)
        Me.Controls.Add(Me.lblZECJohn)
        Me.Controls.Add(Me.lblZECzcor)
        Me.Controls.Add(Me.lblZECZach)
        Me.Controls.Add(Me.lblZECTeam)
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.Name = "frmZECTeamMembers"
        Me.Text = "frmZECTeamMembers"
        CType(Me.pbxMDCJohn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxMDCZach, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxMDCMark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxMDCRebecca, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxMDCBrendan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblZECTeam As Label
    Friend WithEvents lblZECZach As Label
    Friend WithEvents lblZECzcor As Label
    Friend WithEvents lblZECJohn As Label
    Friend WithEvents lblZECjmhoff98 As Label
    Friend WithEvents lblZECRebec As Label
    Friend WithEvents lblZECRebecca As Label
    Friend WithEvents lblZECMark As Label
    Friend WithEvents lblZECmcurry As Label
    Friend WithEvents lblZECBrendan As Label
    Friend WithEvents lblZECbwight4 As Label
    Friend WithEvents pbxMDCJohn As PictureBox
    Friend WithEvents pbxMDCZach As PictureBox
    Friend WithEvents pbxMDCMark As PictureBox
    Friend WithEvents pbxMDCRebecca As PictureBox
    Friend WithEvents pbxMDCBrendan As PictureBox
End Class
