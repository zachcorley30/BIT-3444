﻿'ZEC: This class holds the values for the level of safety the vehicle has
Public Class Safety
    Public Shared Property SafetyList As New List(Of Safety)

    Public Property Item As String
    Public Property Steering As Integer
    Public Property Braking As Integer
    Public Property Airbags As Integer
    Public Property DriveAssist As Integer
    Public Property Weight As Integer

    'ZEC: This sub is run whenever an object of the class is created
    Public Sub New()

    End Sub

End Class
