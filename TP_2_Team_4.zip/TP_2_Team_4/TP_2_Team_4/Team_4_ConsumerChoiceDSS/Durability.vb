﻿'ZEC: This class holds the values for how durable the vehicle is
Public Class Durability
    Public Shared Property DurabilityList As New List(Of Durability)

    Public Property Item As String
    Public Property Steering As Integer
    Public Property OffRoad As Integer
    Public Property Weathering As Integer
    Public Property Vibration As Integer
    Public Property Life As Integer

    'ZEC: This sub is run whenever an object of the class is created
    Public Sub New()

    End Sub

End Class
