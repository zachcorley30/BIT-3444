﻿'ZEC: This class has the purpose of creating objects

Public Class ObjectCreator
    'ZEC: This sub creates a sub that creates objects and lists
    Public Sub CreateObjectsAndLists()
        Dim mySql As String
        Dim myConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\TP_2_Team4.accdb (3).mdb"
        Dim myDataSet As New DataSet
        Dim tableName As String
        Dim myDBMS As New DBMS

        'ZEC: This section of code transfers data from the Acess file to the properties that we have defined for the Comfort table.

        tableName = "Comfort"
        mySql = "SELECT * FROM " & tableName
        myDBMS.RunSQL(tableName, mySql, myDataSet, myConnectionString)
        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myComfort As New Comfort
            myComfort.Item = myDataSet.Tables(tableName).Rows(rowNumber)("Item")
            myComfort.Cushioning = myDataSet.Tables(tableName).Rows(rowNumber)("Cushioning")
            myComfort.Ergonomics = myDataSet.Tables(tableName).Rows(rowNumber)("Ergonomics")
            myComfort.Temperature = myDataSet.Tables(tableName).Rows(rowNumber)("Temperature")
            myComfort.Noise = myDataSet.Tables(tableName).Rows(rowNumber)("Noise")
            myComfort.Storage = myDataSet.Tables(tableName).Rows(rowNumber)("Storage")

            Comfort.ComfortList.Add(myComfort)
        Next

        'ZEC: This section of code transfers data from the Acess file to the properties that we have defined for the Durability table.

        tableName = "Durability"
        mySql = "SELECT * FROM " & tableName
        myDBMS.RunSQL(tableName, mySql, myDataSet, myConnectionString)
        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myDurability As New Durability
            myDurability.Item = myDataSet.Tables(tableName).Rows(rowNumber)("Item")
            myDurability.Steering = myDataSet.Tables(tableName).Rows(rowNumber)("Steering/Joint")
            myDurability.OffRoad = myDataSet.Tables(tableName).Rows(rowNumber)("Off-road")
            myDurability.Weathering = myDataSet.Tables(tableName).Rows(rowNumber)("Weathering")
            myDurability.Vibration = myDataSet.Tables(tableName).Rows(rowNumber)("Vibration Testing")
            myDurability.Life = myDataSet.Tables(tableName).Rows(rowNumber)("Vehicle Life")

            Durability.DurabilityList.Add(myDurability)
        Next

        'ZEC: This section of code transfers data from the Acess file to the properties that we have defined for the Fuel Efficiency table.

        tableName = "Fuel Efficiency"
        mySql = "SELECT * FROM " & tableName
        myDBMS.RunSQL(tableName, mySql, myDataSet, myConnectionString)
        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myFuelEfficiency As New FuelEfficiency
            myFuelEfficiency.Item = myDataSet.Tables(tableName).Rows(rowNumber)("Item")
            myFuelEfficiency.Highway = myDataSet.Tables(tableName).Rows(rowNumber)("Highway")
            myFuelEfficiency.City = myDataSet.Tables(tableName).Rows(rowNumber)("City")

            FuelEfficiency.FuelEfficiencyList.Add(myFuelEfficiency)
        Next

        'ZEC: This section of code transfers data from the Acess file to the properties that we have defined for the Safety table.

        tableName = "Safety"
        mySql = "SELECT * FROM " & tableName
        myDBMS.RunSQL(tableName, mySql, myDataSet, myConnectionString)
        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim mySafety As New Safety
            mySafety.Item = myDataSet.Tables(tableName).Rows(rowNumber)("Item")
            mySafety.Steering = myDataSet.Tables(tableName).Rows(rowNumber)("Steering")
            mySafety.Braking = myDataSet.Tables(tableName).Rows(rowNumber)("Braking")
            mySafety.Airbags = myDataSet.Tables(tableName).Rows(rowNumber)("Airbags")
            mySafety.DriveAssist = myDataSet.Tables(tableName).Rows(rowNumber)("Drive Assist")
            mySafety.Weight = myDataSet.Tables(tableName).Rows(rowNumber)("Weight")

            Safety.SafetyList.Add(mySafety)
        Next

        'ZEC: This section of code transfers data from the Acess file to the properties that we have defined for the User Info table.

        tableName = "Login Info"
        mySql = "SELECT * FROM " & tableName
        myDBMS.RunSQL(tableName, mySql, myDataSet, myConnectionString)
        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myUserID As New UserID
            myUserID.ID = myDataSet.Tables(tableName).Rows(rowNumber)("ID")
            myUserID.Username = myDataSet.Tables(tableName).Rows(rowNumber)("Username")
            myUserID.Password = myDataSet.Tables(tableName).Rows(rowNumber)("Password")

            UserID.UserIDList.Add(myUserID)
        Next

        'ZEC: This section of code transfers data from the Acess file to the properties that we have defined for the Cost table.

        tableName = "Cost"
        mySql = "SELECT * FROM " & tableName
        myDBMS.RunSQL(tableName, mySql, myDataSet, myConnectionString)
        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myCost As New Cost
            myCost.Cost = myDataSet.Tables(tableName).Rows(rowNumber)("Cost")
            myCost.item = myDataSet.Tables(tableName).Rows(rowNumber)("Item")

            Cost.CostList.Add(myCost)
        Next

    End Sub
End Class