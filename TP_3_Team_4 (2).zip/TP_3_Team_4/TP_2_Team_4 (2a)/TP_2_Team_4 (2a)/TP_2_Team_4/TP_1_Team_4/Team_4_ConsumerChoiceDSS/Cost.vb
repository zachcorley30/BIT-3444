﻿'ZEC: This class holds the values for how costly a vehicle is
Public Class Cost
    Public Shared Property CostList As New List(Of Cost)

    Public Property Cost As Integer
    Public Property Item As String

    'ZEC: This sub is run whenever an object of the class is created
    Public Sub New()

    End Sub

End Class
