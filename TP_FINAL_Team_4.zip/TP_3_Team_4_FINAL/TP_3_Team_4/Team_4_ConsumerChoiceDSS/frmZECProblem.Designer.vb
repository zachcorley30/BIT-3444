﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmZECProblem
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblJMHStatement = New System.Windows.Forms.Label()
        Me.lblZECObjective = New System.Windows.Forms.Label()
        Me.lblZECValue = New System.Windows.Forms.Label()
        Me.gbxZECOutput = New System.Windows.Forms.GroupBox()
        Me.tlpZECOutput = New System.Windows.Forms.TableLayoutPanel()
        Me.rtbZECValuePerformance = New System.Windows.Forms.RichTextBox()
        Me.rtbZECValueObjective = New System.Windows.Forms.RichTextBox()
        Me.rtbZECStatement = New System.Windows.Forms.RichTextBox()
        Me.lblBZECTitle = New System.Windows.Forms.Label()
        Me.gbxZECOutput.SuspendLayout()
        Me.tlpZECOutput.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblJMHStatement
        '
        Me.lblJMHStatement.AutoSize = True
        Me.lblJMHStatement.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblJMHStatement.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJMHStatement.Location = New System.Drawing.Point(5, 0)
        Me.lblJMHStatement.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblJMHStatement.Name = "lblJMHStatement"
        Me.lblJMHStatement.Size = New System.Drawing.Size(281, 46)
        Me.lblJMHStatement.TabIndex = 0
        Me.lblJMHStatement.Text = "Statement of DSS"
        '
        'lblZECObjective
        '
        Me.lblZECObjective.AutoSize = True
        Me.lblZECObjective.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECObjective.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECObjective.Location = New System.Drawing.Point(5, 177)
        Me.lblZECObjective.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblZECObjective.Name = "lblZECObjective"
        Me.lblZECObjective.Size = New System.Drawing.Size(332, 46)
        Me.lblZECObjective.TabIndex = 1
        Me.lblZECObjective.Text = "Value of Obj Function"
        '
        'lblZECValue
        '
        Me.lblZECValue.AutoSize = True
        Me.lblZECValue.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECValue.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECValue.Location = New System.Drawing.Point(5, 354)
        Me.lblZECValue.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblZECValue.Name = "lblZECValue"
        Me.lblZECValue.Size = New System.Drawing.Size(488, 92)
        Me.lblZECValue.TabIndex = 2
        Me.lblZECValue.Text = "Value of performance at optimal solution"
        '
        'gbxZECOutput
        '
        Me.gbxZECOutput.BackColor = System.Drawing.Color.White
        Me.gbxZECOutput.Controls.Add(Me.tlpZECOutput)
        Me.gbxZECOutput.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxZECOutput.Location = New System.Drawing.Point(80, 207)
        Me.gbxZECOutput.Margin = New System.Windows.Forms.Padding(5)
        Me.gbxZECOutput.MaximumSize = New System.Drawing.Size(1331, 675)
        Me.gbxZECOutput.Name = "gbxZECOutput"
        Me.gbxZECOutput.Padding = New System.Windows.Forms.Padding(20)
        Me.gbxZECOutput.Size = New System.Drawing.Size(1331, 675)
        Me.gbxZECOutput.TabIndex = 4
        Me.gbxZECOutput.TabStop = False
        Me.gbxZECOutput.Text = "Solution Output"
        '
        'tlpZECOutput
        '
        Me.tlpZECOutput.ColumnCount = 2
        Me.tlpZECOutput.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpZECOutput.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpZECOutput.Controls.Add(Me.rtbZECValuePerformance, 1, 2)
        Me.tlpZECOutput.Controls.Add(Me.rtbZECValueObjective, 1, 1)
        Me.tlpZECOutput.Controls.Add(Me.lblZECValue, 0, 2)
        Me.tlpZECOutput.Controls.Add(Me.lblZECObjective, 0, 1)
        Me.tlpZECOutput.Controls.Add(Me.lblJMHStatement, 0, 0)
        Me.tlpZECOutput.Controls.Add(Me.rtbZECStatement, 1, 0)
        Me.tlpZECOutput.Location = New System.Drawing.Point(139, 83)
        Me.tlpZECOutput.Margin = New System.Windows.Forms.Padding(5)
        Me.tlpZECOutput.Name = "tlpZECOutput"
        Me.tlpZECOutput.RowCount = 3
        Me.tlpZECOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.22222!))
        Me.tlpZECOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.22222!))
        Me.tlpZECOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.22222!))
        Me.tlpZECOutput.Size = New System.Drawing.Size(1099, 532)
        Me.tlpZECOutput.TabIndex = 3
        '
        'rtbZECValuePerformance
        '
        Me.rtbZECValuePerformance.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbZECValuePerformance.Location = New System.Drawing.Point(554, 359)
        Me.rtbZECValuePerformance.Margin = New System.Windows.Forms.Padding(5)
        Me.rtbZECValuePerformance.Name = "rtbZECValuePerformance"
        Me.rtbZECValuePerformance.Size = New System.Drawing.Size(532, 168)
        Me.rtbZECValuePerformance.TabIndex = 5
        Me.rtbZECValuePerformance.Text = ""
        '
        'rtbZECValueObjective
        '
        Me.rtbZECValueObjective.Font = New System.Drawing.Font("Arial Narrow", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbZECValueObjective.Location = New System.Drawing.Point(554, 182)
        Me.rtbZECValueObjective.Margin = New System.Windows.Forms.Padding(5)
        Me.rtbZECValueObjective.Name = "rtbZECValueObjective"
        Me.rtbZECValueObjective.Size = New System.Drawing.Size(532, 167)
        Me.rtbZECValueObjective.TabIndex = 4
        Me.rtbZECValueObjective.Text = ""
        '
        'rtbZECStatement
        '
        Me.rtbZECStatement.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbZECStatement.Location = New System.Drawing.Point(554, 5)
        Me.rtbZECStatement.Margin = New System.Windows.Forms.Padding(5)
        Me.rtbZECStatement.Name = "rtbZECStatement"
        Me.rtbZECStatement.Size = New System.Drawing.Size(532, 167)
        Me.rtbZECStatement.TabIndex = 3
        Me.rtbZECStatement.Text = "This solution provides the ideal car based on the user's vehicle specifications."
        '
        'lblBZECTitle
        '
        Me.lblBZECTitle.AutoSize = True
        Me.lblBZECTitle.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBZECTitle.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBZECTitle.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblBZECTitle.Location = New System.Drawing.Point(668, 94)
        Me.lblBZECTitle.Name = "lblBZECTitle"
        Me.lblBZECTitle.Size = New System.Drawing.Size(202, 63)
        Me.lblBZECTitle.TabIndex = 5
        Me.lblBZECTitle.Text = "Solution"
        '
        'frmZECProblem
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(16.0!, 31.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1504, 1062)
        Me.Controls.Add(Me.lblBZECTitle)
        Me.Controls.Add(Me.gbxZECOutput)
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.MaximumSize = New System.Drawing.Size(1536, 1200)
        Me.MinimumSize = New System.Drawing.Size(1536, 1150)
        Me.Name = "frmZECProblem"
        Me.Padding = New System.Windows.Forms.Padding(20)
        Me.Text = "Problem"
        Me.gbxZECOutput.ResumeLayout(False)
        Me.tlpZECOutput.ResumeLayout(False)
        Me.tlpZECOutput.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblJMHStatement As Label
    Friend WithEvents lblZECObjective As Label
    Friend WithEvents lblZECValue As Label
    Friend WithEvents gbxZECOutput As GroupBox
    Friend WithEvents tlpZECOutput As TableLayoutPanel
    Friend WithEvents rtbZECValuePerformance As RichTextBox
    Friend WithEvents rtbZECValueObjective As RichTextBox
    Friend WithEvents rtbZECStatement As RichTextBox

    Private Sub lblJMHTB1_Click(sender As Object, e As EventArgs) Handles lblJMHStatement.Click

    End Sub

    Private Sub frmZEC_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Friend WithEvents lblBZECTitle As Label
End Class
