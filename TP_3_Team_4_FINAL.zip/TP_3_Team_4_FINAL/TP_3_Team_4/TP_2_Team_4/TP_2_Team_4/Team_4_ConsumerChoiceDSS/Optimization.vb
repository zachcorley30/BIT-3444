﻿Imports Microsoft.SolverFoundation.Common
Imports Microsoft.SolverFoundation.Services
Imports Microsoft.SolverFoundation.Solvers
Public Class Optimization
    Dim Team4Solver As New SimplexSolver
    Dim dvKey As String
    Dim dvIndex As Integer
    Dim coefficient As Single
    Dim constraintKey As String
    Dim constraintIndex As Integer
    Dim objKey As String = "Objective Function"
    Dim objIndex As Integer
    Public optimalObj As Single

    '***************************************************************************************************************
    Public Sub BuildModel()
        '------------------------------------------------------------------------------------------------------------------------
        'ZEC: Define the decision variables
        For Each model As Safety In Safety.SafetyList
            dvKey = model.Item & "_Assigned"
            Team4Solver.AddVariable(dvKey, dvIndex)
            Team4Solver.SetBounds(dvIndex, 0, 1)
            Team4Solver.SetIntegrality(dvIndex, True)
        Next

        'ZEC: The decision variables for D+
        For Each measure As PerformanceMeasure In PerformanceMeasure.PerformanceMeasureList
            dvKey = measure.PerformanceName & "D+"
            Team4Solver.AddVariable(dvKey, dvIndex)
            Team4Solver.SetBounds(dvIndex, 0, Rational.PositiveInfinity)
        Next

        'ZEC: The decision variables for D-
        For Each measure As PerformanceMeasure In PerformanceMeasure.PerformanceMeasureList
            dvKey = measure.PerformanceName & "D-"
            Team4Solver.AddVariable(dvKey, dvIndex)
            Team4Solver.SetBounds(dvIndex, Rational.NegativeInfinity, 0)
        Next
        '-------------------------------------------------------------------------------------------------------------------------
        'ZEC: Now we create the constraints
        'JMH: This constraint makes everything non negative.
        Team4Solver.SetBounds(dvIndex, coefficient, constraintIndex, objIndex, optimalObj, Rational.PositiveInfinity)
        '-----------------------------------------------------------------------------------------------------------------
        'RMD: This constraint ensures the number of purchases is equal to one
        For Each model As Safety In Safety.SafetyList
            constraintKey = "Purchase Constraint" & "_" & model.Item
            Team4Solver.AddRow(constraintKey, constraintIndex)
            Team4Solver.SetBounds(constraintIndex, 1, 1)
        Next
        'RMD: set up the formula for the left hand side of the constraint (I'm not sure this is set up correctly)
        For Each model As Safety In Safety.SafetyList
            dvIndex = Team4Solver.GetIndexFromKey(model.Item) 'RMD: decision variables supposed to go into parentheses??? 
            coefficient = 1
            Team4Solver.SetCoefficient(constraintIndex, dvIndex, coefficient)
        Next
        '---------------------------------------------------------------------------------------------------------------------------------
        'MDC: constraint to measure goal performance for comfort
        For Each model As Comfort In Comfort.ComfortList
            constraintKey = model.Item & "_" & PerformanceMeasure.PerformanceMeasureList(0).PerformanceName
            Team4Solver.AddRow(constraintKey, constraintIndex)

            Dim goalMeasure As Double = frmBWWUserInput.cbxBWWComfort.SelectedValue
            Dim perfMeasure As Double = (model.Cushioning + model.Ergonomics + model.Temperature + model.Noise + model.Storage) / (Comfort.ComfortList.Count - 1)

            Dim deviation As Double = perfMeasure - goalMeasure
            Dim goalBalance As Double

            If deviation >= 0 Then
                goalBalance = 100 * (perfMeasure / goalMeasure) - deviation
                coefficient = goalBalance
            Else
                goalBalance = 100 * (perfMeasure / goalMeasure) + deviation
                coefficient = goalBalance
            End If


            dvIndex = Team4Solver.GetIndexFromKey(model.Item & "_Assigned")
            Team4Solver.SetCoefficient(constraintIndex, dvIndex, coefficient)

            Team4Solver.SetBounds(constraintIndex, 100, 100)
        Next
        'MDC: constraint to measure goal performance for cost
        For Each model As Cost In Cost.CostList
            constraintKey = model.Item & "_" & PerformanceMeasure.PerformanceMeasureList(1).PerformanceName
            Team4Solver.AddRow(constraintKey, constraintIndex)

            Dim goalMeasure As Double = frmBWWUserInput.tbxBWWCost.Text
            Dim perfMeasure As Double = (model.Cost) / (Cost.CostList.Count - 1)

            Dim deviation As Double = perfMeasure - goalMeasure
            Dim goalBalance As Double

            If deviation >= 0 Then
                goalBalance = 100 * (perfMeasure / goalMeasure) - deviation
                coefficient = goalBalance
            Else
                goalBalance = 100 * (perfMeasure / goalMeasure) + deviation
                coefficient = goalBalance
            End If

            dvIndex = Team4Solver.GetIndexFromKey(model.Item & "_Assigned")
            Team4Solver.SetCoefficient(constraintIndex, dvIndex, coefficient)

            Team4Solver.SetBounds(constraintIndex, 100, 100)
        Next
        'MDC: constraint to measure goal performance for durability
        For Each model As Durability In Durability.DurabilityList
            constraintKey = model.Item & "_" & PerformanceMeasure.PerformanceMeasureList(2).PerformanceName
            Team4Solver.AddRow(constraintKey, constraintIndex)

            Dim goalMeasure As Double = frmBWWUserInput.cbxBWWDurability.SelectedValue
            Dim perfMeasure As Double = (model.Steering + model.OffRoad + model.Weathering + model.Vibration + model.Life) / (Durability.DurabilityList.Count - 1)

            Dim deviation As Double = perfMeasure - goalMeasure
            Dim goalBalance As Double

            If deviation >= 0 Then
                goalBalance = 100 * (perfMeasure / goalMeasure) - deviation
                coefficient = goalBalance
            Else
                goalBalance = 100 * (perfMeasure / goalMeasure) + deviation
                coefficient = goalBalance
            End If

            dvIndex = Team4Solver.GetIndexFromKey(model.Item & "_Assigned")
            Team4Solver.SetCoefficient(constraintIndex, dvIndex, coefficient)

            Team4Solver.SetBounds(constraintIndex, 100, 100)
        Next
        'MDC: constraint to measure goal performance for fuel efficiency
        For Each model As FuelEfficiency In FuelEfficiency.FuelEfficiencyList
            constraintKey = model.Item & "_" & PerformanceMeasure.PerformanceMeasureList(3).PerformanceName
            Team4Solver.AddRow(constraintKey, constraintIndex)

            Dim goalMeasure As Double = frmBWWUserInput.cbxBWWFuel.SelectedValue
            Dim perfMeasure As Double = (model.Highway + model.City) / (FuelEfficiency.FuelEfficiencyList.Count - 1)

            Dim deviation As Double = perfMeasure - goalMeasure
            Dim goalBalance As Double

            If deviation >= 0 Then
                goalBalance = 100 * (perfMeasure / goalMeasure) - deviation
                coefficient = goalBalance
            Else
                goalBalance = 100 * (perfMeasure / goalMeasure) + deviation
                coefficient = goalBalance
            End If

            dvIndex = Team4Solver.GetIndexFromKey(model.Item & "_Assigned")
            Team4Solver.SetCoefficient(constraintIndex, dvIndex, coefficient)

            Team4Solver.SetBounds(constraintIndex, 100, 100)
        Next
        'MDC: constraint to measure goal performance for safety
        For Each model As Safety In Safety.SafetyList
            constraintKey = model.Item & "_" & PerformanceMeasure.PerformanceMeasureList(4).PerformanceName
            Team4Solver.AddRow(constraintKey, constraintIndex)

            Dim goalMeasure As Double = frmBWWUserInput.cbxBWWSafety.SelectedValue
            Dim perfMeasure As Double = (model.Steering + model.Braking + model.Airbags + model.DriveAssist + model.Weight) / (Safety.SafetyList.Count - 1)

            Dim deviation As Double = perfMeasure - goalMeasure
            Dim goalBalance As Double

            If deviation >= 0 Then
                goalBalance = 100 * (perfMeasure / goalMeasure) - deviation
                coefficient = goalBalance
            Else
                goalBalance = 100 * (perfMeasure / goalMeasure) + deviation
                coefficient = goalBalance
            End If

            dvIndex = Team4Solver.GetIndexFromKey(model.Item & "_Assigned")
            Team4Solver.SetCoefficient(constraintIndex, dvIndex, coefficient)

            Team4Solver.SetBounds(constraintIndex, 100, 100)
        Next
        '-------------------------------------------------------------------------------------------------------------------------
        'ZEC: This section of code creates the objective function
        objKey = "Total Cost"
        Team4Solver.AddRow(objKey, objIndex)
        For Each measure As PerformanceMeasure In PerformanceMeasure.PerformanceMeasureList
            Dim myPerformanceMeasureIndex As Integer = PerformanceMeasure.PerformanceMeasureList.IndexOf(measure)
            dvKey = measure.PerformanceName & "D+"
            If myPerformanceMeasureIndex = 0 Then coefficient = frmBWWUserInput.cbxBWWComfort.SelectedValue
            If myPerformanceMeasureIndex = 1 Then coefficient = frmBWWUserInput.tbxBWWCost.Text
            If myPerformanceMeasureIndex = 2 Then coefficient = frmBWWUserInput.cbxBWWDurability.SelectedValue
            If myPerformanceMeasureIndex = 3 Then coefficient = frmBWWUserInput.cbxBWWFuel.SelectedValue
            If myPerformanceMeasureIndex = 4 Then coefficient = frmBWWUserInput.cbxBWWSafety.SelectedValue
            Team4Solver.SetCoefficient(objIndex, dvIndex, coefficient)
        Next
        Team4Solver.AddGoal(objIndex, 0, True)

        Team4Solver.AddRow(objKey, objIndex)
        For Each measure As PerformanceMeasure In PerformanceMeasure.PerformanceMeasureList
            Dim myPerformanceMeasureIndex As Integer = PerformanceMeasure.PerformanceMeasureList.IndexOf(measure)
            dvKey = measure.PerformanceName & "D-"
            If myPerformanceMeasureIndex = 0 Then coefficient = frmBWWUserInput.cbxBWWComfort.SelectedValue - 10
            If myPerformanceMeasureIndex = 1 Then coefficient = frmBWWUserInput.tbxBWWCost.Text - 10
            If myPerformanceMeasureIndex = 2 Then coefficient = frmBWWUserInput.cbxBWWDurability.SelectedValue - 10
            If myPerformanceMeasureIndex = 3 Then coefficient = frmBWWUserInput.cbxBWWFuel.SelectedValue - 10
            If myPerformanceMeasureIndex = 4 Then coefficient = frmBWWUserInput.cbxBWWSafety.SelectedValue - 10
            Team4Solver.SetCoefficient(objIndex, dvIndex, coefficient)
        Next
        Team4Solver.AddGoal(objIndex, 0, True)
    End Sub
    '*****************************************************************************************************************
    Public Sub MDCRunModel()
        '----------------------------------------------------------------------------------------------------------
        'MDC:  Solve the optimization

        Dim mySolverParms As New SimplexSolverParams
        mySolverParms.MixedIntegerGapTolerance = 1              'RDB: For IP only - 1 percent gap tolerance between upper and lower bounds of objective function
        mySolverParms.VariableFeasibilityTolerance = 0.00001    'RDB: For IP only - required closeness to a whole number of each variable
        mySolverParms.MaxPivotCount = 1000                      'RDB: Number of iterations.  Increase as necessary
        Team4Solver.Solve(mySolverParms)

        'MDC: We check to see if we got an answer
        If Team4Solver.Result = LinearResult.UnboundedPrimal Then
            MessageBox.Show("Solution is unbounded")
            Exit Sub
        ElseIf _
        Team4Solver.Result = LinearResult.InfeasiblePrimal Then
            MessageBox.Show("Decision model is infeasible")
            Exit Sub
        Else
            Dim dvValues(Safety.SafetyList.Count - 1, PerformanceMeasure.PerformanceMeasureList.Count - 1, PerformanceMeasure.PerformanceMeasureList.Count - 1) As Single
            optimalObj = CSng(Team4Solver.GetValue(objIndex).ToDouble)

            'MDC: print optimal solution and wages in a formatted table
            frmBWWUserInput.rtbBWWSolution.Text = optimalObj
        End If
    End Sub
End Class
