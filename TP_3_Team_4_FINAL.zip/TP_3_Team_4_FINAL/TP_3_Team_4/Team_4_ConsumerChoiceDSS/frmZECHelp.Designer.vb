﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmZECHelp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmZECHelp))
        Me.lblZECHelp = New System.Windows.Forms.Label()
        Me.gbxZECHelp = New System.Windows.Forms.GroupBox()
        Me.lblZECInfo = New System.Windows.Forms.Label()
        Me.gbxZECHelp.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblZECHelp
        '
        Me.lblZECHelp.AutoSize = True
        Me.lblZECHelp.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblZECHelp.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECHelp.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblZECHelp.Location = New System.Drawing.Point(526, 17)
        Me.lblZECHelp.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblZECHelp.Name = "lblZECHelp"
        Me.lblZECHelp.Size = New System.Drawing.Size(189, 49)
        Me.lblZECHelp.TabIndex = 1
        Me.lblZECHelp.Text = "Help Page"
        '
        'gbxZECHelp
        '
        Me.gbxZECHelp.BackColor = System.Drawing.Color.White
        Me.gbxZECHelp.Controls.Add(Me.lblZECInfo)
        Me.gbxZECHelp.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxZECHelp.Location = New System.Drawing.Point(84, 108)
        Me.gbxZECHelp.Margin = New System.Windows.Forms.Padding(6)
        Me.gbxZECHelp.Name = "gbxZECHelp"
        Me.gbxZECHelp.Padding = New System.Windows.Forms.Padding(6)
        Me.gbxZECHelp.Size = New System.Drawing.Size(1048, 485)
        Me.gbxZECHelp.TabIndex = 2
        Me.gbxZECHelp.TabStop = False
        Me.gbxZECHelp.Text = "Help"
        '
        'lblZECInfo
        '
        Me.lblZECInfo.AutoSize = True
        Me.lblZECInfo.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZECInfo.Location = New System.Drawing.Point(70, 56)
        Me.lblZECInfo.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblZECInfo.Name = "lblZECInfo"
        Me.lblZECInfo.Size = New System.Drawing.Size(945, 465)
        Me.lblZECInfo.TabIndex = 0
        Me.lblZECInfo.Text = resources.GetString("lblZECInfo.Text")
        '
        'frmZECHelp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1240, 660)
        Me.Controls.Add(Me.gbxZECHelp)
        Me.Controls.Add(Me.lblZECHelp)
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.Name = "frmZECHelp"
        Me.Text = "frmZECHelp"
        Me.gbxZECHelp.ResumeLayout(False)
        Me.gbxZECHelp.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblZECHelp As Label
    Friend WithEvents gbxZECHelp As GroupBox
    Friend WithEvents lblZECInfo As Label
End Class
