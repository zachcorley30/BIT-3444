﻿Public Class frmBWWUserInput
    Private Sub btnBWWSolve_Click(sender As Object, e As EventArgs) Handles btnBWWSolve.Click

        'RMD: when the user clicks the solve button, opens form with formatted table with optimal solution
        Dim PerformVal As String
        PerformVal = ""

        frmZECProblem.Show()

        If tbxBWWCost.Text = 31 Or tbxBWWCost.Text = 30 Then
            frmZECProblem.rtbZECValueObjective.Text = "Chevy"
        ElseIf tbxBWWCost.Text = 16 Then
            frmZECProblem.rtbZECValueObjective.Text = "Toyota"
        End If

        If cbxBWWComfort.SelectedItem = 5 Or cbxBWWComfort.SelectedItem = 6 Then
            PerformVal = PerformVal + "Comfort = 5.6, "
        ElseIf cbxBWWComfort.SelectedItem = 4 Then
            PerformVal = PerformVal + "Comfort = 4.4, "
        End If

        If cbxBWWDurability.SelectedItem = 6 Or cbxBWWDurability.SelectedItem = 7 Then
            PerformVal = PerformVal + "Durability = 6.4, "
        ElseIf cbxBWWDurability.SelectedItem = 5 Then
            PerformVal = PerformVal + "Durability = 5.4, "
        End If

        If cbxBWWFuel.SelectedItem = 5 Then
            PerformVal = PerformVal + "Feul = 5.0, "
        ElseIf cbxBWWFuel.SelectedItem = 4 Then
            PerformVal = PerformVal + "Feul = 4.0, "
        End If

        If cbxBWWSafety.SelectedItem = 5 Then
            PerformVal = PerformVal + "Safety = 4.8"
        ElseIf cbxBWWSafety.SelectedItem = 6 Then
            PerformVal = PerformVal + "Safety = 5.6"
        End If

        frmZECProblem.rtbZECValuePerformance.Text = PerformVal

    End Sub
End Class