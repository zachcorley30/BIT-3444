﻿Imports System.Data.OleDb                             'RDB: We use the OleDB namespace for an MS Access namespace
'**************************************************************************************************************************
Public Class DBMS
    'ADO.NET Data Provider Objects
    Private Team4DataAdapter As New OleDbDataAdapter    'Team4: ADO.NET DataAdapter Object -  The DataAdapter facilitates the conversion from the external Database to the internal DataSet
    Private Team4Connection As New OleDbConnection      'Team4: ADO.NET Connection Object property -  
    Private Team4ConnectionString As String             'Team4: ADO.NET Connection Object property -  The connection string is found in the app.config file.  This string points to the external DataBase
    Private Team4SQL As String                          'Team4: ADO.NET Command Object property - This string is declared for any SQL statements that we will write
    Private Team4DataSet As New DataSet                 'Team4: ADO.NET DataSet Object - The external Database will be transformed into an internal DataSetDim orderList As New List(Of SalesOrder)
    Private Team4Command As New OleDbCommand            'Team4: ADO.NET DataSet Command Object - sql commands are conveyed via a Command object
    Private Team4TableName As String                    'Team4: sql Commands are executed on tables
    '**************************************************************************************************************************
    Public Sub New()
        ' This sub creates a new DBMSe object

    End Sub
    '**************************************************************************************************************************
    Public Sub RunSQL(ByVal Team4TableName, ByVal Team4SQL, ByVal Team4DataSet, ByVal Team4ConnectionString)
        '
        'Team4:  First we build the Database Connection Object
        Team4Connection.ConnectionString = Team4ConnectionString      'Team4:  We use the Connection String that is found in the app.config file to connect to the DataBase
        Team4Command = Team4Connection.CreateCommand()
        '
        'Team4: Now we build the Command that will be sent to the Data Adapter
        Team4Command.CommandText = Team4SQL                            'Team4: The sql is embedded in an object called a Command
        '
        'Team4: Now we build the Data Adapter
        Team4DataAdapter.SelectCommand = Team4Command                  'Team4: The DataAdaptor executes the query Command
        Team4DataAdapter.Fill(Team4DataSet, Team4TableName)              'Team4: The Fill method of the DataAdaptor fills tables in the DataSet from data from the DataBase

    End Sub
End Class

