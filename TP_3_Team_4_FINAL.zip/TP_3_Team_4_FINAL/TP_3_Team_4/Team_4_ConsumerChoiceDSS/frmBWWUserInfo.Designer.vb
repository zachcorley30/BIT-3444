﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBWWUserInput
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblBWWTitle = New System.Windows.Forms.Label()
        Me.gbxBWWCarData = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbxBWWSafety = New System.Windows.Forms.ComboBox()
        Me.cbxBWWFuel = New System.Windows.Forms.ComboBox()
        Me.cbxBWWDurability = New System.Windows.Forms.ComboBox()
        Me.cbxBWWComfort = New System.Windows.Forms.ComboBox()
        Me.tbxBWWCost = New System.Windows.Forms.TextBox()
        Me.lblMDCSafety = New System.Windows.Forms.Label()
        Me.lblMDCFuelEff = New System.Windows.Forms.Label()
        Me.lblMDCDurability = New System.Windows.Forms.Label()
        Me.lblMDCComfort = New System.Windows.Forms.Label()
        Me.lblMDCCost = New System.Windows.Forms.Label()
        Me.lblBWWCarSpecification = New System.Windows.Forms.Label()
        Me.btnBWWSolve = New System.Windows.Forms.Button()
        Me.gbxBWWCarData.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblBWWTitle
        '
        Me.lblBWWTitle.AutoSize = True
        Me.lblBWWTitle.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWTitle.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWTitle.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblBWWTitle.Location = New System.Drawing.Point(70, 9)
        Me.lblBWWTitle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBWWTitle.Name = "lblBWWTitle"
        Me.lblBWWTitle.Size = New System.Drawing.Size(508, 31)
        Me.lblBWWTitle.TabIndex = 0
        Me.lblBWWTitle.Text = "What type of vehicle do you want to purchase?"
        '
        'gbxBWWCarData
        '
        Me.gbxBWWCarData.BackColor = System.Drawing.Color.Snow
        Me.gbxBWWCarData.Controls.Add(Me.Label1)
        Me.gbxBWWCarData.Controls.Add(Me.cbxBWWSafety)
        Me.gbxBWWCarData.Controls.Add(Me.cbxBWWFuel)
        Me.gbxBWWCarData.Controls.Add(Me.cbxBWWDurability)
        Me.gbxBWWCarData.Controls.Add(Me.cbxBWWComfort)
        Me.gbxBWWCarData.Controls.Add(Me.tbxBWWCost)
        Me.gbxBWWCarData.Controls.Add(Me.lblMDCSafety)
        Me.gbxBWWCarData.Controls.Add(Me.lblMDCFuelEff)
        Me.gbxBWWCarData.Controls.Add(Me.lblMDCDurability)
        Me.gbxBWWCarData.Controls.Add(Me.lblMDCComfort)
        Me.gbxBWWCarData.Controls.Add(Me.lblMDCCost)
        Me.gbxBWWCarData.Controls.Add(Me.lblBWWCarSpecification)
        Me.gbxBWWCarData.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxBWWCarData.Location = New System.Drawing.Point(34, 59)
        Me.gbxBWWCarData.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.gbxBWWCarData.Name = "gbxBWWCarData"
        Me.gbxBWWCarData.Padding = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.gbxBWWCarData.Size = New System.Drawing.Size(400, 277)
        Me.gbxBWWCarData.TabIndex = 1
        Me.gbxBWWCarData.TabStop = False
        Me.gbxBWWCarData.Text = "Car Data"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(317, 83)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 22)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "thousand"
        '
        'cbxBWWSafety
        '
        Me.cbxBWWSafety.FormattingEnabled = True
        Me.cbxBWWSafety.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cbxBWWSafety.Location = New System.Drawing.Point(210, 227)
        Me.cbxBWWSafety.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.cbxBWWSafety.Name = "cbxBWWSafety"
        Me.cbxBWWSafety.Size = New System.Drawing.Size(106, 25)
        Me.cbxBWWSafety.TabIndex = 25
        '
        'cbxBWWFuel
        '
        Me.cbxBWWFuel.FormattingEnabled = True
        Me.cbxBWWFuel.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cbxBWWFuel.Location = New System.Drawing.Point(210, 192)
        Me.cbxBWWFuel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.cbxBWWFuel.Name = "cbxBWWFuel"
        Me.cbxBWWFuel.Size = New System.Drawing.Size(106, 25)
        Me.cbxBWWFuel.TabIndex = 24
        '
        'cbxBWWDurability
        '
        Me.cbxBWWDurability.FormattingEnabled = True
        Me.cbxBWWDurability.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cbxBWWDurability.Location = New System.Drawing.Point(210, 155)
        Me.cbxBWWDurability.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.cbxBWWDurability.Name = "cbxBWWDurability"
        Me.cbxBWWDurability.Size = New System.Drawing.Size(106, 25)
        Me.cbxBWWDurability.TabIndex = 23
        '
        'cbxBWWComfort
        '
        Me.cbxBWWComfort.FormattingEnabled = True
        Me.cbxBWWComfort.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cbxBWWComfort.Location = New System.Drawing.Point(210, 121)
        Me.cbxBWWComfort.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.cbxBWWComfort.Name = "cbxBWWComfort"
        Me.cbxBWWComfort.Size = New System.Drawing.Size(106, 25)
        Me.cbxBWWComfort.TabIndex = 22
        '
        'tbxBWWCost
        '
        Me.tbxBWWCost.Location = New System.Drawing.Point(210, 83)
        Me.tbxBWWCost.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.tbxBWWCost.Name = "tbxBWWCost"
        Me.tbxBWWCost.Size = New System.Drawing.Size(106, 23)
        Me.tbxBWWCost.TabIndex = 20
        '
        'lblMDCSafety
        '
        Me.lblMDCSafety.AutoSize = True
        Me.lblMDCSafety.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCSafety.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCSafety.Location = New System.Drawing.Point(38, 227)
        Me.lblMDCSafety.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMDCSafety.Name = "lblMDCSafety"
        Me.lblMDCSafety.Size = New System.Drawing.Size(48, 22)
        Me.lblMDCSafety.TabIndex = 18
        Me.lblMDCSafety.Text = "Safety"
        '
        'lblMDCFuelEff
        '
        Me.lblMDCFuelEff.AutoSize = True
        Me.lblMDCFuelEff.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCFuelEff.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCFuelEff.Location = New System.Drawing.Point(38, 192)
        Me.lblMDCFuelEff.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMDCFuelEff.Name = "lblMDCFuelEff"
        Me.lblMDCFuelEff.Size = New System.Drawing.Size(100, 22)
        Me.lblMDCFuelEff.TabIndex = 17
        Me.lblMDCFuelEff.Text = "Fuel Efficiency"
        '
        'lblMDCDurability
        '
        Me.lblMDCDurability.AutoSize = True
        Me.lblMDCDurability.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCDurability.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCDurability.Location = New System.Drawing.Point(38, 155)
        Me.lblMDCDurability.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMDCDurability.Name = "lblMDCDurability"
        Me.lblMDCDurability.Size = New System.Drawing.Size(68, 22)
        Me.lblMDCDurability.TabIndex = 16
        Me.lblMDCDurability.Text = "Durability"
        '
        'lblMDCComfort
        '
        Me.lblMDCComfort.AutoSize = True
        Me.lblMDCComfort.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCComfort.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCComfort.Location = New System.Drawing.Point(38, 119)
        Me.lblMDCComfort.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMDCComfort.Name = "lblMDCComfort"
        Me.lblMDCComfort.Size = New System.Drawing.Size(60, 22)
        Me.lblMDCComfort.TabIndex = 15
        Me.lblMDCComfort.Text = "Comfort"
        '
        'lblMDCCost
        '
        Me.lblMDCCost.AutoSize = True
        Me.lblMDCCost.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCCost.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCCost.Location = New System.Drawing.Point(38, 83)
        Me.lblMDCCost.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMDCCost.Name = "lblMDCCost"
        Me.lblMDCCost.Size = New System.Drawing.Size(138, 22)
        Me.lblMDCCost.TabIndex = 14
        Me.lblMDCCost.Text = "Cost (In Thousands)"
        '
        'lblBWWCarSpecification
        '
        Me.lblBWWCarSpecification.AutoSize = True
        Me.lblBWWCarSpecification.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblBWWCarSpecification.Font = New System.Drawing.Font("Arial Narrow", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBWWCarSpecification.Location = New System.Drawing.Point(14, 40)
        Me.lblBWWCarSpecification.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBWWCarSpecification.Name = "lblBWWCarSpecification"
        Me.lblBWWCarSpecification.Size = New System.Drawing.Size(317, 24)
        Me.lblBWWCarSpecification.TabIndex = 1
        Me.lblBWWCarSpecification.Text = "What car specifications do you require?"
        '
        'btnBWWSolve
        '
        Me.btnBWWSolve.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBWWSolve.Location = New System.Drawing.Point(480, 166)
        Me.btnBWWSolve.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.btnBWWSolve.Name = "btnBWWSolve"
        Me.btnBWWSolve.Size = New System.Drawing.Size(130, 49)
        Me.btnBWWSolve.TabIndex = 2
        Me.btnBWWSolve.Text = "Solve"
        Me.btnBWWSolve.UseVisualStyleBackColor = True
        '
        'frmBWWUserInput
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(650, 380)
        Me.Controls.Add(Me.btnBWWSolve)
        Me.Controls.Add(Me.gbxBWWCarData)
        Me.Controls.Add(Me.lblBWWTitle)
        Me.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.Name = "frmBWWUserInput"
        Me.Text = "User Input"
        Me.gbxBWWCarData.ResumeLayout(False)
        Me.gbxBWWCarData.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBWWTitle As Label
    Friend WithEvents gbxBWWCarData As GroupBox
    Friend WithEvents lblBWWCarSpecification As Label
    Friend WithEvents btnBWWSolve As Button
    Friend WithEvents tbxBWWCost As TextBox
    Friend WithEvents lblMDCSafety As Label
    Friend WithEvents lblMDCFuelEff As Label
    Friend WithEvents lblMDCDurability As Label
    Friend WithEvents lblMDCComfort As Label
    Friend WithEvents lblMDCCost As Label
    Friend WithEvents cbxBWWSafety As ComboBox
    Friend WithEvents cbxBWWFuel As ComboBox
    Friend WithEvents cbxBWWDurability As ComboBox
    Friend WithEvents cbxBWWComfort As ComboBox
    Friend WithEvents Label1 As Label
End Class
