﻿Public Class frmZECProblem
    Private Sub gbxZECOutput_Enter(sender As Object, e As EventArgs) Handles gbxZECOutput.Enter

    End Sub
End Class