﻿Public Class frmZECWelcome
    Private Sub btnZECExit_Click(sender As Object, e As EventArgs) Handles btnZECExit.Click
        Me.Close()
    End Sub

    Private Sub btnZECtoHelp_Click(sender As Object, e As EventArgs) Handles btnZECtoHelp.Click
        frmZECHelp.Show()
    End Sub

    Private Sub btnZECToTeam_Click(sender As Object, e As EventArgs) Handles btnZECToTeam.Click
        frmZECTeamMembers.Show()
    End Sub

    Private Sub btnZECToUser_Click(sender As Object, e As EventArgs) Handles btnZECToUser.Click
        frmBWWUserInput.Show()
    End Sub

    Private Sub btnZECToProblem_Click(sender As Object, e As EventArgs) Handles btnZECToProblem.Click
        frmZECProblem.Show()
    End Sub

    Private Sub btnZECToData_Click(sender As Object, e As EventArgs) Handles btnZECToData.Click
        frmMDCStrucData.Show()
    End Sub

    Private Sub btnZECEnter_Click(sender As Object, e As EventArgs) Handles btnZECEnter.Click
        If txtZECUsername.Text = "user" Then
            If txtZECPassword.Text = "user6" Then
                btnZECToUser.Show()
                btnZECToProblem.Show()
            End If
        End If

        If txtZECUsername.Text = "bwight" Then
            If txtZECPassword.Text = "bwight2" Then
                btnZECToUser.Show()
                btnZECToProblem.Show()
                btnZECToData.Show()
            End If
        End If

        If txtZECUsername.Text = "mcurry" Then
            If txtZECPassword.Text = "mcurry4" Then
                btnZECToUser.Show()
                btnZECToProblem.Show()
                btnZECToData.Show()
            End If
        End If

        If txtZECUsername.Text = "rdryden" Then
            If txtZECPassword.Text = "rdryden5" Then
                btnZECToUser.Show()
                btnZECToProblem.Show()
                btnZECToData.Show()
            End If
        End If
    End Sub
End Class