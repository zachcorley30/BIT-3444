﻿Public Class RMDFuelEfficiency

    Public Sub New()


    End Sub

    Public Property Brand As String
    Public Property Highway As Integer
    Public Property City As Integer


End Class
