﻿Public Class RMDDurability

    Public Sub New()

    End Sub

    Public Property Brand As String
    Public Property Steering As Integer
    Public Property OffRoad As Integer
    Public Property Weathering As Integer
    Public Property Vibration As Integer
    Public Property Life As Integer
End Class
