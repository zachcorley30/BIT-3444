﻿Public Class RMDStrucData

    Public Sub New()

    End Sub

    Public Property UserMake As Integer
    Public Property UserCost As Integer
    Public Property UserComfort As Integer
    Public Property UserDurability As Integer
    Public Property UserEfficiency As Integer
    Public Property UserSaftey As Integer

End Class
