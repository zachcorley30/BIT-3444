﻿Public Class RMDComfort

    Public Sub New()

    End Sub

    Public Property Brand As String
    Public Property Cushioning As Integer
    Public Property Ergonomics As Integer
    Public Property Temperature As Integer
    Public Property Noise As Integer
    Public Property Storage As Integer


End Class
