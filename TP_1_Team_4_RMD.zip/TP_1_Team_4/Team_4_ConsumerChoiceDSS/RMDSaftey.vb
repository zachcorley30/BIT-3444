﻿Public Class RMDSaftey

    Public Sub New()

    End Sub

    Public Property Brand As String
    Public Property Steering As Integer
    Public Property Braking As Integer
    Public Property Airbags As Integer
    Public Property DriveAssist As Integer
    Public Property Weight As Integer

End Class
