﻿Public Class RMDUserID
    Public Sub New()

    End Sub

    Public Property Brand As String
    Public Property Username As Integer
    Public Property Password As Integer

End Class
