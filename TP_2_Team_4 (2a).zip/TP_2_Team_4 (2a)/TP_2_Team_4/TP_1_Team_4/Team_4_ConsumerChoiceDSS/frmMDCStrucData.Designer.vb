﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMDCStrucData
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMDCData = New System.Windows.Forms.Label()
        Me.lblMDCMake = New System.Windows.Forms.Label()
        Me.lblMDCCost = New System.Windows.Forms.Label()
        Me.lblMDCComfort = New System.Windows.Forms.Label()
        Me.lblMDCDurability = New System.Windows.Forms.Label()
        Me.lblMDCFuelEff = New System.Windows.Forms.Label()
        Me.lblMDCSafety = New System.Windows.Forms.Label()
        Me.tbxMDCMake = New System.Windows.Forms.TextBox()
        Me.tbxMDCCost = New System.Windows.Forms.TextBox()
        Me.tbxMDCComfort = New System.Windows.Forms.TextBox()
        Me.tbxMDCDurability = New System.Windows.Forms.TextBox()
        Me.tbxMDCFuelEff = New System.Windows.Forms.TextBox()
        Me.tbxMDCSafety = New System.Windows.Forms.TextBox()
        Me.gbxMDCData = New System.Windows.Forms.GroupBox()
        Me.gbxMDCData.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblMDCData
        '
        Me.lblMDCData.AutoSize = True
        Me.lblMDCData.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCData.Font = New System.Drawing.Font("Arial Narrow", 16.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCData.Location = New System.Drawing.Point(416, 42)
        Me.lblMDCData.Name = "lblMDCData"
        Me.lblMDCData.Size = New System.Drawing.Size(267, 52)
        Me.lblMDCData.TabIndex = 0
        Me.lblMDCData.Text = "Car Data Input"
        '
        'lblMDCMake
        '
        Me.lblMDCMake.AutoSize = True
        Me.lblMDCMake.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCMake.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCMake.Location = New System.Drawing.Point(36, 59)
        Me.lblMDCMake.Name = "lblMDCMake"
        Me.lblMDCMake.Size = New System.Drawing.Size(108, 31)
        Me.lblMDCMake.TabIndex = 1
        Me.lblMDCMake.Text = "Car Make"
        '
        'lblMDCCost
        '
        Me.lblMDCCost.AutoSize = True
        Me.lblMDCCost.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCCost.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCCost.Location = New System.Drawing.Point(36, 120)
        Me.lblMDCCost.Name = "lblMDCCost"
        Me.lblMDCCost.Size = New System.Drawing.Size(59, 31)
        Me.lblMDCCost.TabIndex = 2
        Me.lblMDCCost.Text = "Cost"
        '
        'lblMDCComfort
        '
        Me.lblMDCComfort.AutoSize = True
        Me.lblMDCComfort.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCComfort.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCComfort.Location = New System.Drawing.Point(36, 176)
        Me.lblMDCComfort.Name = "lblMDCComfort"
        Me.lblMDCComfort.Size = New System.Drawing.Size(91, 31)
        Me.lblMDCComfort.TabIndex = 3
        Me.lblMDCComfort.Text = "Comfort"
        '
        'lblMDCDurability
        '
        Me.lblMDCDurability.AutoSize = True
        Me.lblMDCDurability.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCDurability.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCDurability.Location = New System.Drawing.Point(36, 232)
        Me.lblMDCDurability.Name = "lblMDCDurability"
        Me.lblMDCDurability.Size = New System.Drawing.Size(105, 31)
        Me.lblMDCDurability.TabIndex = 4
        Me.lblMDCDurability.Text = "Durability"
        '
        'lblMDCFuelEff
        '
        Me.lblMDCFuelEff.AutoSize = True
        Me.lblMDCFuelEff.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCFuelEff.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCFuelEff.Location = New System.Drawing.Point(36, 290)
        Me.lblMDCFuelEff.Name = "lblMDCFuelEff"
        Me.lblMDCFuelEff.Size = New System.Drawing.Size(157, 31)
        Me.lblMDCFuelEff.TabIndex = 5
        Me.lblMDCFuelEff.Text = "Fuel Efficiency"
        '
        'lblMDCSafety
        '
        Me.lblMDCSafety.AutoSize = True
        Me.lblMDCSafety.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblMDCSafety.Font = New System.Drawing.Font("Arial Narrow", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDCSafety.Location = New System.Drawing.Point(36, 345)
        Me.lblMDCSafety.Name = "lblMDCSafety"
        Me.lblMDCSafety.Size = New System.Drawing.Size(76, 31)
        Me.lblMDCSafety.TabIndex = 6
        Me.lblMDCSafety.Text = "Safety"
        '
        'tbxMDCMake
        '
        Me.tbxMDCMake.Location = New System.Drawing.Point(247, 59)
        Me.tbxMDCMake.Name = "tbxMDCMake"
        Me.tbxMDCMake.Size = New System.Drawing.Size(156, 32)
        Me.tbxMDCMake.TabIndex = 7
        '
        'tbxMDCCost
        '
        Me.tbxMDCCost.Location = New System.Drawing.Point(247, 120)
        Me.tbxMDCCost.Name = "tbxMDCCost"
        Me.tbxMDCCost.Size = New System.Drawing.Size(156, 32)
        Me.tbxMDCCost.TabIndex = 8
        '
        'tbxMDCComfort
        '
        Me.tbxMDCComfort.Location = New System.Drawing.Point(247, 176)
        Me.tbxMDCComfort.Name = "tbxMDCComfort"
        Me.tbxMDCComfort.Size = New System.Drawing.Size(100, 32)
        Me.tbxMDCComfort.TabIndex = 9
        '
        'tbxMDCDurability
        '
        Me.tbxMDCDurability.Location = New System.Drawing.Point(247, 232)
        Me.tbxMDCDurability.Name = "tbxMDCDurability"
        Me.tbxMDCDurability.Size = New System.Drawing.Size(100, 32)
        Me.tbxMDCDurability.TabIndex = 10
        '
        'tbxMDCFuelEff
        '
        Me.tbxMDCFuelEff.Location = New System.Drawing.Point(247, 290)
        Me.tbxMDCFuelEff.Name = "tbxMDCFuelEff"
        Me.tbxMDCFuelEff.Size = New System.Drawing.Size(100, 32)
        Me.tbxMDCFuelEff.TabIndex = 11
        '
        'tbxMDCSafety
        '
        Me.tbxMDCSafety.Location = New System.Drawing.Point(247, 345)
        Me.tbxMDCSafety.Name = "tbxMDCSafety"
        Me.tbxMDCSafety.Size = New System.Drawing.Size(100, 32)
        Me.tbxMDCSafety.TabIndex = 12
        '
        'gbxMDCData
        '
        Me.gbxMDCData.BackColor = System.Drawing.Color.Snow
        Me.gbxMDCData.Controls.Add(Me.tbxMDCSafety)
        Me.gbxMDCData.Controls.Add(Me.tbxMDCFuelEff)
        Me.gbxMDCData.Controls.Add(Me.tbxMDCDurability)
        Me.gbxMDCData.Controls.Add(Me.tbxMDCComfort)
        Me.gbxMDCData.Controls.Add(Me.tbxMDCCost)
        Me.gbxMDCData.Controls.Add(Me.tbxMDCMake)
        Me.gbxMDCData.Controls.Add(Me.lblMDCSafety)
        Me.gbxMDCData.Controls.Add(Me.lblMDCFuelEff)
        Me.gbxMDCData.Controls.Add(Me.lblMDCDurability)
        Me.gbxMDCData.Controls.Add(Me.lblMDCComfort)
        Me.gbxMDCData.Controls.Add(Me.lblMDCCost)
        Me.gbxMDCData.Controls.Add(Me.lblMDCMake)
        Me.gbxMDCData.Font = New System.Drawing.Font("Arial Narrow", 7.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxMDCData.Location = New System.Drawing.Point(180, 149)
        Me.gbxMDCData.Name = "gbxMDCData"
        Me.gbxMDCData.Size = New System.Drawing.Size(731, 406)
        Me.gbxMDCData.TabIndex = 13
        Me.gbxMDCData.TabStop = False
        Me.gbxMDCData.Text = "Input Data"
        '
        'frmMDCStrucData
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1091, 634)
        Me.Controls.Add(Me.gbxMDCData)
        Me.Controls.Add(Me.lblMDCData)
        Me.Name = "frmMDCStrucData"
        Me.Text = "Structural Data"
        Me.gbxMDCData.ResumeLayout(False)
        Me.gbxMDCData.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMDCData As Label
    Friend WithEvents lblMDCMake As Label
    Friend WithEvents lblMDCCost As Label
    Friend WithEvents lblMDCComfort As Label
    Friend WithEvents lblMDCDurability As Label
    Friend WithEvents lblMDCFuelEff As Label
    Friend WithEvents lblMDCSafety As Label
    Friend WithEvents tbxMDCMake As TextBox
    Friend WithEvents tbxMDCCost As TextBox
    Friend WithEvents tbxMDCComfort As TextBox
    Friend WithEvents tbxMDCDurability As TextBox
    Friend WithEvents tbxMDCFuelEff As TextBox
    Friend WithEvents tbxMDCSafety As TextBox
    Friend WithEvents gbxMDCData As GroupBox
End Class
