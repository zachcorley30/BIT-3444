﻿'ZEC: This class holds the values for the level of comfort for the vehicle
Public Class Comfort
    Public Shared Property ComfortList As New List(Of Comfort)

    Public Property Item As String
    Public Property Cushioning As Integer
    Public Property Ergonomics As Integer
    Public Property Temperature As Integer
    Public Property Noise As Integer
    Public Property Storage As Integer

    'ZEC: This sub is run whenever an object of the class is created
    Public Sub New()

    End Sub

End Class
