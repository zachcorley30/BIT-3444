﻿'ZEC: This class holds the values for how the vehicle is ranked in terms of fuel efficiency
Public Class FuelEfficiency
    Public Shared Property FuelEfficiencyList As New List(Of FuelEfficiency)


    Public Property Item As String
    Public Property Highway As Integer
    Public Property City As Integer

    'ZEC: This sub is run whenever an object of the class is created
    Public Sub New()

    End Sub

End Class