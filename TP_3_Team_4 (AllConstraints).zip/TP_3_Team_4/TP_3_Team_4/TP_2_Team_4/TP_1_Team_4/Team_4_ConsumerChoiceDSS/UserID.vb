﻿'ZEC: This class holds the values for usernames and passwords
Public Class UserID
    Public Shared Property UserIDList As New List(Of UserID)

    Public Property ID As Integer
    Public Property Username As String
    Public Property Password As String

    'ZEC: This sub is run whenever an object of the class is created
    Public Sub New()

    End Sub

End Class
