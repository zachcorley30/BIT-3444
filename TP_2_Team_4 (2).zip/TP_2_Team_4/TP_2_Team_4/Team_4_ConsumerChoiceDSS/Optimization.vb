﻿Imports Microsoft.SolverFoundation.Common
Imports Microsoft.SolverFoundation.Services
Imports Microsoft.SolverFoundation.Solvers
Public Class Optimization
    Dim Team4Solver As New SimplexSolver
    Dim dvKey As String
    Dim dvIndex As Integer
    Dim coefficient As Single
    Dim constraintKey As String
    Dim constraintIndex As Integer
    Dim objKey As String = "Objective Function"
    Dim objIndex As Integer
    Public optimalObj As Single

    '***************************************************************************************************************
    Public Sub BuildModel()
        '------------------------------------------------------------------------------------------------------------------------
        'ZEC: Define the decision variables
        For Each model As Safety In Safety.SafetyList
            dvKey = model.Item & "_Assigned"
            Team4Solver.AddVariable(dvKey, dvIndex)
            Team4Solver.SetBounds(dvIndex, 0, 1)
            Team4Solver.SetIntegrality(dvIndex, True)
        Next

        'ZEC: The decision variables for D+
        For Each measure As PerformanceMeasure In PerformanceMeasure.PerformanceMeasureList
            dvKey = measure.PerformanceName & "D+"
            Team4Solver.AddVariable(dvKey, dvIndex)
            Team4Solver.SetBounds(dvIndex, 0, Rational.PositiveInfinity)
        Next

        'ZEC: The decision variables for D-
        For Each measure As PerformanceMeasure In PerformanceMeasure.PerformanceMeasureList
            dvKey = measure.PerformanceName & "D-"
            Team4Solver.AddVariable(dvKey, dvIndex)
            Team4Solver.SetBounds(dvIndex, Rational.NegativeInfinity, 0)
        Next
        '-------------------------------------------------------------------------------------------------------------------------
        'ZEC: Now we create the constraints


        '-------------------------------------------------------------------------------------------------------------------------
        'ZEC: This section of code creates the objective function
        objKey = "Total Cost"
        Team4Solver.AddRow(objKey, objIndex)
        For Each measure As PerformanceMeasure In PerformanceMeasure.PerformanceMeasureList
            Dim myPerformanceMeasureIndex As Integer = PerformanceMeasure.PerformanceMeasureList.IndexOf(measure)
            dvKey = measure.PerformanceName & "D+"
            If myPerformanceMeasureIndex = 0 Then coefficient = frmBWWUserInput.cbxBWWComfort.SelectedValue
            If myPerformanceMeasureIndex = 1 Then coefficient = frmBWWUserInput.tbxBWWCost.Text
            If myPerformanceMeasureIndex = 2 Then coefficient = frmBWWUserInput.cbxBWWDurability.SelectedValue
            If myPerformanceMeasureIndex = 3 Then coefficient = frmBWWUserInput.cbxBWWFuel.SelectedValue
            If myPerformanceMeasureIndex = 4 Then coefficient = frmBWWUserInput.cbxBWWSafety.SelectedValue
            Team4Solver.SetCoefficient(objIndex, dvIndex, coefficient)
        Next
        Team4Solver.AddGoal(objIndex, 0, True)

        Team4Solver.AddRow(objKey, objIndex)
        For Each measure As PerformanceMeasure In PerformanceMeasure.PerformanceMeasureList
            Dim myPerformanceMeasureIndex As Integer = PerformanceMeasure.PerformanceMeasureList.IndexOf(measure)
            dvKey = measure.PerformanceName & "D-"
            If myPerformanceMeasureIndex = 0 Then coefficient = frmBWWUserInput.cbxBWWComfort.SelectedValue - 10
            If myPerformanceMeasureIndex = 1 Then coefficient = frmBWWUserInput.tbxBWWCost.Text - 10
            If myPerformanceMeasureIndex = 2 Then coefficient = frmBWWUserInput.cbxBWWDurability.SelectedValue - 10
            If myPerformanceMeasureIndex = 3 Then coefficient = frmBWWUserInput.cbxBWWFuel.SelectedValue - 10
            If myPerformanceMeasureIndex = 4 Then coefficient = frmBWWUserInput.cbxBWWSafety.SelectedValue - 10
            Team4Solver.SetCoefficient(objIndex, dvIndex, coefficient)
        Next
        Team4Solver.AddGoal(objIndex, 0, True)
    End Sub

End Class
